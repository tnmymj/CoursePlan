
import React, { useState } from 'react';
import { Search, Bell, Menu, X, BookOpen, User, LayoutDashboard } from 'lucide-react';
import { NavItem } from '../types';

interface HeaderProps {
  onSearch: (query: string) => void;
  activeNav: NavItem | 'Dashboard';
  setActiveNav: (nav: NavItem | 'Dashboard') => void;
  isLoggedIn: boolean;
  onOpenAuth: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, activeNav, setActiveNav, isLoggedIn, onOpenAuth }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const navItems: NavItem[] = ['Home', 'Course Breakdown', 'Marketplace', 'How It Works'];

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    onSearch(val);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo & Desktop Nav */}
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 flex-shrink-0 cursor-pointer" onClick={() => setActiveNav('Home')}>
              <div className="bg-blue-600 p-1.5 rounded-lg">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-800 tracking-tighter">
                Course Plan
              </span>
            </div>

            <nav className="hidden lg:flex items-center space-x-6">
              {navItems.map((item) => (
                <button
                  key={item}
                  onClick={() => setActiveNav(item)}
                  className={`text-[13px] font-black uppercase tracking-widest transition-all ${
                    activeNav === item ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  {item}
                </button>
              ))}
              {isLoggedIn && (
                <button
                  onClick={() => setActiveNav('Dashboard')}
                  className={`text-[13px] font-black uppercase tracking-widest transition-all flex items-center gap-1.5 ${
                    activeNav === 'Dashboard' ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </button>
              )}
            </nav>
          </div>

          {/* Search, Notifications & Profile */}
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center relative w-64 lg:w-80">
              <input
                type="text"
                placeholder="Search resources..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full pl-4 pr-10 py-2.5 bg-[#f8fafc] border border-gray-100 rounded-xl text-xs font-bold focus:outline-none focus:ring-4 focus:ring-blue-500/5 transition-all"
              />
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
            </div>

            {isLoggedIn ? (
              <button 
                onClick={() => setActiveNav('Dashboard')}
                className="hidden sm:flex items-center gap-2.5 p-1 bg-slate-50 border border-slate-100 rounded-full hover:bg-blue-50 transition-all pr-4"
              >
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-black text-[10px]">
                   JH
                </div>
                <span className="text-xs font-black text-slate-600 uppercase tracking-widest">Jahid</span>
              </button>
            ) : (
              <button 
                onClick={onOpenAuth}
                className="hidden sm:flex items-center gap-2 px-6 py-2.5 text-xs font-black uppercase tracking-widest text-white bg-slate-900 hover:bg-blue-600 rounded-xl transition-all active:scale-95"
              >
                Get Started
              </button>
            )}

            {/* Mobile menu button */}
            <button 
              className="lg:hidden p-2 text-slate-400 hover:bg-slate-50 rounded-lg"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-b border-gray-100 px-4 pt-2 pb-6 space-y-1 animate-in slide-in-from-top duration-200">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => {
                setActiveNav(item);
                setIsMenuOpen(false);
              }}
              className={`block w-full text-left px-4 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all ${
                activeNav === item ? 'bg-blue-50 text-blue-600' : 'text-slate-400 hover:bg-slate-50'
              }`}
            >
              {item}
            </button>
          ))}
          {!isLoggedIn && (
            <div className="pt-4 border-t border-slate-50">
               <button 
                onClick={() => { onOpenAuth(); setIsMenuOpen(false); }}
                className="w-full py-3 font-black uppercase tracking-widest text-white bg-blue-600 rounded-xl"
              >
                Sign In
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default Header;
