
export type UserRole = 'USER' | 'PAID_MEMBER' | 'ANALYST' | 'ADMIN' | 'SUPER_ADMIN';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING';

export interface BreakdownSection {
  title: string;
  content: string;
  isFree: boolean;
  image?: string; 
}

export interface Course {
  id: string;
  title: string;
  platform: string;
  description: string;
  price: number;
  thumbnail: string;
  category: string;
  rating: number;
  // Added breakdownSummary to resolve property not found errors in constants.ts
  breakdownSummary?: string[];
  breakdownSections?: BreakdownSection[];
  affiliateUrl?: string; // For suggested courses
}

export interface Affiliate {
  id: string;
  name: string;
  logo: string;
  description: string;
  categories: string[];
  url: string;
  type: 'PLATFORM' | 'COURSE'; 
}

export type NavItem = 'Home' | 'Course Breakdown' | 'Marketplace' | 'How It Works' | 'Suggested Courses' | 'Privacy Policy' | 'Terms of Service';

export type DashboardTab = 
  | 'My CourseBreakDown' 
  | 'My Offers' 
  | 'Marketplace' 
  | 'Updates'
  | 'Suggested Course';

export type ManagementTab = 
  | 'Our Course Breakdown'
  | 'Suggested Courses Management'
  | 'Marketplace Management'
  | 'Manage Users'
  | 'Assign Roles'
  | 'Paid Users'
  | 'Banned Users';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  bio?: string;
  avatar: string;
  role: UserRole;
  status?: UserStatus;
  joinedAt?: string;
  isPaid?: boolean;
  purchasedCourseIds?: string[];
}
