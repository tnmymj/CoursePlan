
import React, { useState, useEffect } from 'react';
import { Search, Menu, X, BookOpen, ChevronRight, LayoutDashboard, Shield } from 'lucide-react';
import { NavItem, UserRole } from '../types';

interface HeaderProps {
  onSearch: (query: string) => void;
  activeNav: NavItem | 'Dashboard' | 'Management';
  setActiveNav: (nav: NavItem | 'Dashboard' | 'Management') => void;
  isLoggedIn: boolean;
  userRole?: UserRole;
  userName?: string;
  onOpenAuth: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, activeNav, setActiveNav, isLoggedIn, userRole, userName, onOpenAuth }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: NavItem[] = ['Home', 'Course Breakdown', 'Marketplace', 'How It Works'];
  const isManagementAllowed = userRole === 'ADMIN' || userRole === 'SUPER_ADMIN' || userRole === 'ANALYST';

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    onSearch(val);
  };

  return (
    <header className={`sticky top-0 z-[60] w-full transition-all duration-500 ${
      scrolled 
        ? 'py-4 glass-header border-b border-white/5 shadow-2xl shadow-black/50' 
        : 'py-8 bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center gap-12">
            <div className="flex items-center gap-3 flex-shrink-0 cursor-pointer group" onClick={() => setActiveNav('Home')}>
              <div className="bg-cyan-500 p-2 rounded-xl shadow-lg shadow-cyan-500/20 group-hover:scale-110 transition-transform">
                <BookOpen className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight font-['Outfit']">
                Course <span className="text-cyan-400">Plan</span>
              </span>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-2">
              {navItems.map((item) => (
                <button
                  key={item}
                  onClick={() => setActiveNav(item)}
                  className={`px-5 py-2.5 rounded-full text-[13px] font-bold transition-all duration-300 ${
                    activeNav === item 
                      ? 'bg-cyan-500/10 text-cyan-400' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {item}
                </button>
              ))}
              
              {isLoggedIn && isManagementAllowed && (
                <button
                  onClick={() => setActiveNav('Management')}
                  className={`px-5 py-2.5 rounded-full text-[13px] font-bold transition-all duration-300 flex items-center gap-2 ${
                    activeNav === 'Management' 
                      ? 'bg-blue-500/20 text-blue-400' 
                      : 'text-blue-400/60 hover:text-blue-400'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" />
                  Management
                </button>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center relative w-72">
              <input
                type="text"
                placeholder="Search resources..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full pl-12 pr-6 py-3 bg-white/5 border border-white/10 rounded-full text-[13px] font-medium focus:outline-none focus:ring-4 focus:ring-cyan-500/10 focus:bg-white/10 focus:border-cyan-500/30 transition-all placeholder:text-slate-500 text-white"
              />
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            </div>

            {isLoggedIn ? (
              <button 
                onClick={() => setActiveNav('Dashboard')}
                className="hidden sm:flex items-center gap-4 p-1.5 bg-slate-900 border border-white/10 rounded-full hover:border-cyan-500/40 transition-all group pr-6"
              >
                <div className="w-9 h-9 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center font-bold text-xs uppercase">
                   {userName?.substring(0, 2) || 'US'}
                </div>
                <div className="flex flex-col items-start leading-none">
                  <span className="text-[12px] font-bold text-white">{userName || 'User'}</span>
                  <span className="text-[9px] font-semibold text-cyan-400 uppercase tracking-widest">{userRole || 'MEMBER'}</span>
                </div>
              </button>
            ) : (
              <button 
                onClick={onOpenAuth}
                className="hidden sm:flex items-center gap-2 px-8 py-3.5 text-[13px] font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 cyan-glow rounded-full transition-all active:scale-95"
              >
                Get Started
                <ChevronRight className="w-4 h-4" />
              </button>
            )}

            <button 
              className="lg:hidden p-3 text-slate-400 hover:bg-white/5 rounded-full transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[88px] bg-slate-950 border-b border-white/10 px-6 pt-4 pb-10 space-y-2 animate-in slide-in-from-top-4 duration-300 z-50 shadow-2xl">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => { setActiveNav(item); setIsMenuOpen(false); }}
              className={`block w-full text-left px-6 py-4 rounded-2xl text-[15px] font-bold transition-all ${
                activeNav === item ? 'bg-cyan-500/10 text-cyan-400' : 'text-slate-400 hover:bg-white/5'
              }`}
            >
              {item}
            </button>
          ))}
          
          {isLoggedIn && isManagementAllowed && (
            <button
              onClick={() => { setActiveNav('Management'); setIsMenuOpen(false); }}
              className={`block w-full text-left px-6 py-4 rounded-2xl text-[15px] font-bold text-blue-400 transition-all ${
                activeNav === 'Management' ? 'bg-blue-500/10' : 'hover:bg-white/5'
              }`}
            >
              Management Panel
            </button>
          )}

          {isLoggedIn && (
             <button
              onClick={() => { setActiveNav('Dashboard'); setIsMenuOpen(false); }}
              className={`block w-full text-left px-6 py-4 rounded-2xl text-[15px] font-bold text-white transition-all ${
                activeNav === 'Dashboard' ? 'bg-white/10' : 'hover:bg-white/5'
              }`}
            >
              My Dashboard
            </button>
          )}

          {!isLoggedIn && (
            <div className="pt-8 px-2">
               <button 
                onClick={() => { onOpenAuth(); setIsMenuOpen(false); }}
                className="w-full py-5 font-bold text-slate-950 bg-cyan-400 rounded-full shadow-xl shadow-cyan-500/20"
              >
                Sign In
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default Header;
