
import React, { useState, useRef, useEffect } from 'react';
import { 
  Plus, Book, LayoutGrid, Shield, 
  Trash2, Edit3, Save, 
  ArrowLeft, ExternalLink,
  Sparkles, ImagePlus,
  CheckCircle2, AlertCircle, Info, Search, Lock, Unlock, User, Mail, Pencil, X, 
  ShieldCheck, Loader2, UserCog, UserMinus, UserPlus, Ban, Trash, RefreshCcw,
  ImageIcon
} from 'lucide-react';
import { supabase } from '../supabase';
import { ManagementTab, UserRole, Course, Affiliate, UserProfile, BreakdownSection } from '../types';
import { showToast } from './Toast';

interface ManagementDashboardProps {
  user: UserProfile;
  userRole: UserRole;
  courses: Course[];
  setCourses: React.Dispatch<React.SetStateAction<Course[]>>;
  affiliates: Affiliate[];
  setAffiliates: React.Dispatch<React.SetStateAction<Affiliate[]>>;
  suggestedCourses: Course[];
  setSuggestedCourses: React.Dispatch<React.SetStateAction<Course[]>>;
  onLogout: () => void;
  onBackToMain: () => void;
}

const ManagementDashboard: React.FC<ManagementDashboardProps> = ({ 
  user: currentUser,
  userRole, 
  courses, 
  setCourses, 
  affiliates, 
  setAffiliates, 
  suggestedCourses, 
  setSuggestedCourses, 
  onLogout, 
  onBackToMain 
}) => {
  const [activeTab, setActiveTab] = useState<ManagementTab | 'My Profile'>('Our Course Breakdown');
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadingSectionIdx, setUploadingSectionIdx] = useState<number | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [dynamicSections, setDynamicSections] = useState<BreakdownSection[]>([
    { title: '১. কোর্সের ওভারভিউ', content: '', isFree: true },
    { title: '২. মডিউল এনালাইসিস', content: '', isFree: true }
  ]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sectionFileInputRef = useRef<HTMLInputElement>(null);
  const isAnalyst = userRole === 'ANALYST';
  const isSuperAdmin = userRole === 'SUPER_ADMIN';

  useEffect(() => {
    if (activeTab === 'Manage Users' || activeTab === 'Assign Roles' || activeTab === 'Paid Users' || activeTab === 'Banned Users') {
      fetchUsers();
    }
  }, [activeTab]);

  const fetchUsers = async () => {
    setLoadingUsers(true);
    try {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      setUsers(data || []);
    } catch (err: any) {
      showToast('ইউজার লিস্ট লোড করা যায়নি: ' + err.message, 'error');
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isSection: boolean = false, idx: number | null = null) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (isSection) setUploadingSectionIdx(idx);
    else setIsUploading(true);

    try {
      const bucket = 'course-assets';
      const fileExt = file.name.split('.').pop();
      const fileName = `uploads/${Date.now()}_${Math.random().toString(36).substr(2, 9)}.${fileExt}`;

      const { error: uploadError } = await supabase.storage.from(bucket).upload(fileName, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(fileName);
      
      if (isSection && idx !== null) {
        const next = [...dynamicSections];
        next[idx].image = publicUrl;
        setDynamicSections(next);
        showToast('সেকশন ইমেজ আপলোড সফল!', 'success');
      } else {
        setSelectedImage(publicUrl);
        showToast('থাম্বনেইল আপলোড সফল!', 'success');
      }
    } catch (err: any) {
      showToast('আপলোড ব্যর্থ: ' + err.message, 'error');
    } finally {
      setIsUploading(false);
      setUploadingSectionIdx(null);
    }
  };

  const handleDelete = async (id: string, table: string) => {
    if (!window.confirm('আপনি কি নিশ্চিত যে এটি ডিলিট করতে চান?')) return;
    
    try {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      
      if (table === 'courses') setCourses(courses.filter(c => c.id !== id));
      if (table === 'affiliates') setAffiliates(affiliates.filter(a => a.id !== id));
      if (table === 'suggested_courses') setSuggestedCourses(suggestedCourses.filter(s => s.id !== id));
      if (table === 'profiles') setUsers(users.filter(u => u.id !== id));
      
      showToast('সফলভাবে ডিলিট করা হয়েছে', 'success');
    } catch (err: any) {
      showToast('ডিলিট করা যায়নি: ' + err.message, 'error');
    }
  };

  const handleUserRoleChange = async (userId: string, newRole: UserRole) => {
    try {
      const { error } = await supabase.from('profiles').update({ role: newRole }).eq('id', userId);
      if (error) throw error;
      setUsers(users.map(u => u.id === userId ? { ...u, role: newRole } : u));
      showToast(`রোল আপডেট করা হয়েছে: ${newRole}`, 'success');
    } catch (err: any) {
      showToast('রোল আপডেট করা যায়নি: ' + err.message, 'error');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedImage && !editingItem) {
      showToast('দয়া করে একটি ইমেজ আপলোড করুন', 'error');
      return;
    }
    setIsSubmitting(true);
    const formData = new FormData(e.target as HTMLFormElement);
    const data: any = Object.fromEntries(formData.entries());

    try {
      if (activeTab === 'Our Course Breakdown') {
        const payload = {
          title: data.title,
          platform: data.platform,
          price: Number(data.price),
          category: data.category,
          rating: Number(data.rating),
          thumbnail: selectedImage || editingItem?.thumbnail,
          description: data.description,
          breakdown_sections: dynamicSections
        };

        const { data: result, error } = editingItem 
          ? await supabase.from('courses').update(payload).eq('id', editingItem.id).select()
          : await supabase.from('courses').insert([payload]).select();

        if (error) throw error;
        const mappedResult = { ...result[0], breakdownSections: result[0].breakdown_sections };
        setCourses(editingItem ? courses.map(c => c.id === editingItem.id ? mappedResult : c) : [mappedResult, ...courses]);
      } else if (activeTab === 'Marketplace Management') {
         const payload = {
          name: data.name,
          url: data.url,
          logo: selectedImage || editingItem?.logo,
          description: data.description,
          type: data.type,
          categories: data.categories?.split(',').map((c: string) => c.trim()) || []
        };
        const { data: result, error } = editingItem 
          ? await supabase.from('affiliates').update(payload).eq('id', editingItem.id).select()
          : await supabase.from('affiliates').insert([payload]).select();

        if (error) throw error;
        setAffiliates(editingItem ? affiliates.map(a => a.id === editingItem.id ? result[0] : a) : [result[0], ...affiliates]);
      } else if (activeTab === 'Suggested Courses Management') {
        const payload = {
          title: data.title,
          platform: data.platform,
          price: Number(data.price),
          category: data.category,
          rating: Number(data.rating),
          thumbnail: selectedImage || editingItem?.thumbnail,
          description: data.description,
          affiliate_url: data.affiliate_url
        };
        const { data: result, error } = editingItem 
          ? await supabase.from('suggested_courses').update(payload).eq('id', editingItem.id).select()
          : await supabase.from('suggested_courses').insert([payload]).select();

        if (error) throw error;
        const mappedResult = { ...result[0], affiliateUrl: result[0].affiliate_url };
        setSuggestedCourses(editingItem ? suggestedCourses.map(s => s.id === editingItem.id ? mappedResult : s) : [mappedResult, ...suggestedCourses]);
      }

      showToast('সফলভাবে সেভ করা হয়েছে', 'success');
      resetForm();
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingItem(null);
    setSelectedImage(null);
    setDynamicSections([
      { title: '১. কোর্সের ওভারভিউ', content: '', isFree: true },
      { title: '২. মডিউল এনালাইসিস', content: '', isFree: true }
    ]);
  };

  const getCurrentList = () => {
    switch (activeTab) {
      case 'Our Course Breakdown': return courses;
      case 'Marketplace Management': return affiliates;
      case 'Suggested Courses Management': return suggestedCourses;
      case 'Manage Users': return users;
      case 'Paid Users': return users.filter(u => u.role === 'PAID_MEMBER');
      case 'Banned Users': return users.filter(u => u.status === 'SUSPENDED');
      default: return [];
    }
  };

  return (
    <div className="min-h-screen bg-[#F1F5F9] flex font-['Plus_Jakarta_Sans']">
      {/* SIDEBAR */}
      <aside className="w-80 bg-[#0F172A] flex flex-col shadow-2xl sticky top-0 h-screen z-20">
        <div className="p-8 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-black text-white tracking-tighter">COURSE <span className="text-blue-500">PLAN</span></h1>
          </div>
        </div>
        
        <nav className="flex-1 overflow-y-auto px-6 py-8 space-y-2">
           <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-5 mb-4">Content Management</div>
           <button onClick={() => { setActiveTab('Our Course Breakdown'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'Our Course Breakdown' && !showForm ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <Book className="w-4 h-4" /> Course Breakdown
           </button>
           <button onClick={() => { setActiveTab('Suggested Courses Management'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'Suggested Courses Management' && !showForm ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <Sparkles className="w-4 h-4" /> Suggested Courses
           </button>
           <button onClick={() => { setActiveTab('Marketplace Management'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'Marketplace Management' && !showForm ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <LayoutGrid className="w-4 h-4" /> Marketplace
           </button>

           <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-5 mt-10 mb-4">User Controls</div>
           <button onClick={() => { setActiveTab('Manage Users'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'Manage Users' ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <UserCog className="w-4 h-4" /> User Management
           </button>
           <button onClick={() => { setActiveTab('Paid Users'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'Paid Users' ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <ShieldCheck className="w-4 h-4" /> Paid Members
           </button>

           <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-5 mt-10 mb-4">System</div>
           <button onClick={() => { setActiveTab('My Profile'); resetForm(); }} className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-[13px] font-bold transition-all ${activeTab === 'My Profile' ? 'bg-blue-600 text-white shadow-xl translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
             <User className="w-4 h-4" /> My Profile
           </button>
        </nav>
        
        <div className="p-8 border-t border-slate-800">
          <button onClick={onBackToMain} className="w-full py-3.5 text-slate-400 font-bold hover:bg-slate-800 rounded-2xl flex items-center justify-center gap-2 mb-2"><ArrowLeft className="w-4 h-4" /> Exit Panel</button>
          <button onClick={onLogout} className="w-full py-3.5 text-rose-500 font-bold hover:bg-rose-900/30 rounded-2xl transition-all">Sign Out</button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 overflow-y-auto">
        <header className="bg-white/95 backdrop-blur-xl border-b border-slate-200 px-12 py-8 flex items-center justify-between sticky top-0 z-30 shadow-sm">
          <div>
             <h2 className="text-2xl font-black text-slate-900">{showForm ? 'Asset Creation' : activeTab}</h2>
             <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">System Operational</p>
             </div>
          </div>
          {!showForm && !isAnalyst && (activeTab === 'Our Course Breakdown' || activeTab === 'Suggested Courses Management' || activeTab === 'Marketplace Management') && (
            <button onClick={() => setShowForm(true)} className="px-8 py-4 bg-slate-900 text-white text-[13px] font-black rounded-2xl shadow-xl hover:bg-blue-600 transition-all flex items-center gap-2 active:scale-95">
              <Plus className="w-5 h-5" /> ADD NEW
            </button>
          )}
        </header>

        <div className="p-12 max-w-[1400px] mx-auto">
          {showForm ? (
            <div className="bg-white rounded-[3.5rem] border-2 border-slate-200 shadow-2xl p-16 animate-in slide-in-from-bottom-4 duration-500">
               <form onSubmit={handleSave} className="space-y-12">
                  <div className="flex flex-col items-center mb-10">
                     <div 
                      className="w-56 h-36 bg-slate-50 rounded-3xl border-4 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all relative overflow-hidden group"
                      onClick={() => fileInputRef.current?.click()}
                     >
                       {(selectedImage || editingItem?.thumbnail || editingItem?.logo) ? (
                         <img src={selectedImage || editingItem?.thumbnail || editingItem?.logo} className="w-full h-full object-cover" alt="Preview" />
                       ) : (
                         <>
                           <ImagePlus className="w-10 h-10 text-slate-400 mb-2 group-hover:text-blue-500 transition-colors" />
                           <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">থাম্বনেইল আপলোড</span>
                         </>
                       )}
                       {isUploading && (
                         <div className="absolute inset-0 bg-white/90 flex items-center justify-center">
                            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                         </div>
                       )}
                     </div>
                     <p className="text-[11px] text-slate-500 mt-4 font-black uppercase tracking-widest">Main Display Image</p>
                     <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e)} />
                  </div>

                  <div className="grid grid-cols-2 gap-10">
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">নাম / টাইটেল</label>
                      <input name={activeTab === 'Marketplace Management' ? 'name' : 'title'} defaultValue={editingItem?.title || editingItem?.name} required className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl font-bold outline-none focus:border-blue-600 focus:bg-white transition-all text-slate-900" />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">প্ল্যাটফর্ম / লিঙ্ক</label>
                      <input name={activeTab === 'Marketplace Management' ? 'url' : (activeTab === 'Suggested Courses Management' ? 'affiliate_url' : 'platform')} defaultValue={editingItem?.platform || editingItem?.url || editingItem?.affiliateUrl} required className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl font-bold outline-none focus:border-blue-600 focus:bg-white transition-all text-slate-900" />
                    </div>
                  </div>

                  {(activeTab === 'Our Course Breakdown' || activeTab === 'Suggested Courses Management') && (
                    <div className="grid grid-cols-3 gap-10">
                      <div className="space-y-3">
                        <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">প্রাইস (TK)</label>
                        <input name="price" type="number" defaultValue={editingItem?.price} className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl font-bold outline-none focus:border-blue-600 focus:bg-white transition-all text-slate-900" />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">রেটিং</label>
                        <input name="rating" type="number" step="0.1" defaultValue={editingItem?.rating} className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl font-bold outline-none focus:border-blue-600 focus:bg-white transition-all text-slate-900" />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">ক্যাটাগরি</label>
                        <input name="category" defaultValue={editingItem?.category} className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl font-bold outline-none focus:border-blue-600 focus:bg-white transition-all text-slate-900" />
                      </div>
                    </div>
                  )}

                  <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-700 uppercase tracking-widest ml-2">শর্ট ডেসক্রিপশন</label>
                    <textarea name="description" defaultValue={editingItem?.description} className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-300 rounded-2xl h-36 outline-none focus:border-blue-600 focus:bg-white transition-all font-medium text-slate-800" />
                  </div>

                  {activeTab === 'Our Course Breakdown' && (
                    <div className="space-y-8">
                      <div className="flex items-center gap-4">
                        <h4 className="text-lg font-black text-slate-900 font-['Outfit']">ব্রেকডাউন মডিউল এনালাইসিস</h4>
                        <div className="flex-1 h-[2px] bg-slate-200"></div>
                      </div>
                      <div className="space-y-6">
                        {dynamicSections.map((section, idx) => (
                          <div key={idx} className="p-10 bg-slate-50 border-2 border-slate-300 rounded-[2.5rem] space-y-6 shadow-md hover:shadow-xl transition-shadow relative overflow-hidden">
                            <div className="flex items-center gap-4">
                                <span className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center font-black">{idx + 1}</span>
                                <input value={section.title} onChange={(e) => { const next = [...dynamicSections]; next[idx].title = e.target.value; setDynamicSections(next); }} className="flex-1 bg-transparent font-black border-b-2 border-slate-300 py-3 text-xl focus:border-blue-600 outline-none text-slate-900" placeholder="মডিউল নাম" />
                            </div>
                            
                            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                               <div className="lg:col-span-3">
                                  <textarea value={section.content} onChange={(e) => { const next = [...dynamicSections]; next[idx].content = e.target.value; setDynamicSections(next); }} className="w-full bg-white border-2 border-slate-200 p-6 rounded-2xl min-h-[180px] font-medium leading-relaxed text-slate-800 outline-none focus:border-blue-500" placeholder="এনালাইসিস লিখুন..." />
                               </div>
                               <div className="lg:col-span-1">
                                  <div 
                                    className="w-full h-full min-h-[180px] bg-white border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 group overflow-hidden relative"
                                    onClick={() => {
                                      const input = document.getElementById(`section-file-${idx}`) as HTMLInputElement;
                                      input?.click();
                                    }}
                                  >
                                    {section.image ? (
                                      <img src={section.image} className="w-full h-full object-cover" alt="" />
                                    ) : (
                                      <>
                                        <ImageIcon className="w-6 h-6 text-slate-300 mb-2 group-hover:text-blue-500" />
                                        <span className="text-[9px] font-black text-slate-400 uppercase">সেকশন ইমেজ</span>
                                      </>
                                    )}
                                    {uploadingSectionIdx === idx && (
                                      <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
                                         <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                                      </div>
                                    )}
                                  </div>
                                  <input 
                                    type="file" 
                                    id={`section-file-${idx}`} 
                                    className="hidden" 
                                    accept="image/*" 
                                    onChange={(e) => handleFileUpload(e, true, idx)} 
                                  />
                               </div>
                            </div>

                            <div className="flex items-center justify-between pt-2">
                               <div className="flex items-center gap-6">
                                  <label className="flex items-center gap-3 cursor-pointer group">
                                    <div className={`w-10 h-6 rounded-full transition-all relative flex items-center p-1 ${section.isFree ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                                      <input type="checkbox" checked={section.isFree} onChange={(e) => { const next = [...dynamicSections]; next[idx].isFree = e.target.checked; setDynamicSections(next); }} className="hidden" />
                                      <div className={`w-4 h-4 bg-white rounded-full transition-all ${section.isFree ? 'translate-x-4' : 'translate-x-0'}`}></div>
                                    </div>
                                    <span className={`text-xs font-black uppercase tracking-widest ${section.isFree ? 'text-emerald-600' : 'text-slate-500'}`}>
                                      {section.isFree ? 'FREE PREVIEW' : 'LOCKED CONTENT'}
                                    </span>
                                  </label>
                               </div>
                               <button type="button" onClick={() => setDynamicSections(dynamicSections.filter((_, i) => i !== idx))} className="flex items-center gap-2 text-rose-600 text-[11px] font-black uppercase hover:text-rose-800 transition-colors">
                                  <Trash className="w-3.5 h-3.5" /> REMOVE MODULE
                               </button>
                            </div>
                          </div>
                        ))}
                        <button type="button" onClick={() => setDynamicSections([...dynamicSections, { title: 'নতুন সেকশন', content: '', isFree: false }])} className="w-full py-5 border-4 border-dashed border-slate-300 rounded-[2rem] text-slate-500 font-black hover:border-blue-600 hover:text-blue-600 hover:bg-blue-50 transition-all flex items-center justify-center gap-2">
                           <Plus className="w-5 h-5" /> ADD ANOTHER ANALYSIS MODULE
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-6 pt-10">
                     <button type="submit" disabled={isSubmitting || isUploading || uploadingSectionIdx !== null} className="flex-1 py-6 bg-blue-600 text-white font-black rounded-2xl shadow-xl hover:bg-slate-900 transition-all disabled:opacity-50 text-base uppercase tracking-widest">
                       {isSubmitting ? 'Syncing...' : 'SAVE CHANGES'}
                     </button>
                     <button type="button" onClick={resetForm} className="px-12 py-6 bg-slate-100 text-slate-600 font-black rounded-2xl hover:bg-slate-200 transition-all text-base uppercase tracking-widest">CANCEL</button>
                  </div>
               </form>
            </div>
          ) : activeTab === 'My Profile' ? (
            <div className="bg-white rounded-[3.5rem] border-2 border-slate-200 shadow-2xl p-20 text-center max-w-3xl mx-auto">
               <div className="w-40 h-40 mx-auto rounded-full overflow-hidden border-[12px] border-slate-50 mb-10 shadow-2xl">
                  <img src={currentUser.avatar} className="w-full h-full object-cover" alt="" />
               </div>
               <h2 className="text-4xl font-black text-slate-900 mb-3 font-['Outfit']">{currentUser.name}</h2>
               <p className="text-blue-600 font-black text-xl mb-6">{currentUser.email}</p>
               <div className="inline-block px-10 py-3 bg-slate-900 text-white rounded-2xl text-[12px] font-black uppercase tracking-[0.4em] mb-12 shadow-lg">
                  System Role: {currentUser.role}
               </div>
            </div>
          ) : (activeTab === 'Manage Users' || activeTab === 'Paid Users' || activeTab === 'Banned Users') ? (
            <div className="bg-white rounded-[3.5rem] border-2 border-slate-200 shadow-2xl overflow-hidden">
                <div className="p-10 border-b-2 border-slate-100 flex items-center justify-between bg-slate-50/50">
                   <div className="relative w-[400px]">
                      <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <input placeholder="Search users..." className="w-full pl-14 pr-8 py-4 bg-white rounded-2xl text-sm font-bold outline-none border-2 border-slate-200 focus:border-blue-600 transition-all" />
                   </div>
                   <button onClick={fetchUsers} className="flex items-center gap-2 px-6 py-4 bg-white border-2 border-slate-200 rounded-2xl hover:bg-blue-50 text-slate-700 font-black text-xs transition-all">
                      <RefreshCcw className={`w-4 h-4 ${loadingUsers ? 'animate-spin' : ''}`} /> RELOAD
                   </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                      <thead>
                        <tr className="bg-slate-900 text-white">
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest">User Details</th>
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest">Role</th>
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y-2 divide-slate-100">
                        {loadingUsers ? (
                          <tr><td colSpan={3} className="py-32 text-center text-slate-500 font-black animate-pulse">Syncing...</td></tr>
                        ) : getCurrentList().length > 0 ? getCurrentList().map((u: any) => (
                            <tr key={u.id} className="hover:bg-blue-50/40 transition-all group">
                              <td className="px-12 py-10">
                                  <div className="flex items-center gap-6">
                                     <img src={u.avatar} className="w-16 h-16 rounded-2xl object-cover border-4 border-white shadow-xl" alt="" />
                                     <div>
                                        <div className="font-black text-slate-900 text-xl leading-none mb-2">{u.name}</div>
                                        <div className="text-[13px] font-bold text-slate-500">{u.email}</div>
                                     </div>
                                  </div>
                              </td>
                              <td className="px-12 py-10">
                                  <span className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 ${
                                    u.role === 'ADMIN' || u.role === 'SUPER_ADMIN' ? 'bg-indigo-600 text-white border-indigo-700' : 
                                    u.role === 'PAID_MEMBER' ? 'bg-emerald-600 text-white border-emerald-700' : 'bg-slate-100 text-slate-500 border-slate-200'
                                  }`}>
                                     {u.role}
                                  </span>
                              </td>
                              <td className="px-12 py-10 text-right">
                                  <div className="flex items-center justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all">
                                     {u.role !== 'PAID_MEMBER' && (
                                       <button onClick={() => handleUserRoleChange(u.id, 'PAID_MEMBER')} className="p-4 bg-emerald-100 text-emerald-700 rounded-2xl hover:bg-emerald-600 hover:text-white transition-all shadow-md">
                                         <UserPlus className="w-5 h-5" />
                                       </button>
                                     )}
                                     {u.role === 'PAID_MEMBER' && (
                                       <button onClick={() => handleUserRoleChange(u.id, 'USER')} className="p-4 bg-slate-200 text-slate-600 rounded-2xl hover:bg-slate-900 hover:text-white transition-all shadow-md">
                                         <UserMinus className="w-5 h-5" />
                                       </button>
                                     )}
                                     {isSuperAdmin && (
                                       <button onClick={() => handleUserRoleChange(u.id, 'ADMIN')} className="p-4 bg-indigo-100 text-indigo-700 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-md">
                                         <ShieldCheck className="w-5 h-5" />
                                       </button>
                                     )}
                                     <button onClick={() => handleDelete(u.id, 'profiles')} className="p-4 bg-rose-100 text-rose-600 rounded-2xl hover:bg-rose-600 hover:text-white transition-all shadow-md">
                                        <Trash2 className="w-5 h-5" />
                                     </button>
                                  </div>
                              </td>
                            </tr>
                        )) : (
                          <tr><td colSpan={3} className="py-32 text-center text-slate-400 font-black italic">No users found</td></tr>
                        )}
                      </tbody>
                  </table>
                </div>
            </div>
          ) : (
            <div className="bg-white rounded-[3.5rem] border-2 border-slate-200 shadow-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                      <thead>
                        <tr className="bg-slate-900 text-white">
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest">Asset Details</th>
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest">Platform</th>
                            <th className="px-12 py-7 text-[11px] font-black uppercase tracking-widest text-right">Controls</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y-2 divide-slate-100">
                        {getCurrentList().length > 0 ? getCurrentList().map((item: any) => (
                            <tr key={item.id} className="hover:bg-blue-50/40 transition-all group">
                              <td className="px-12 py-10 flex items-center gap-6">
                                  <img src={item.thumbnail || item.logo} className="w-20 h-20 rounded-2xl object-cover border-4 border-white shadow-xl" alt="" />
                                  <div>
                                    <div className="font-black text-slate-900 text-2xl leading-tight mb-2">{item.title || item.name}</div>
                                    <div className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-widest rounded-lg border border-blue-200">{item.category || item.type}</div>
                                  </div>
                              </td>
                              <td className="px-12 py-10">
                                  <span className="text-[13px] font-black text-slate-600 uppercase bg-slate-100 px-5 py-2.5 rounded-xl border-2 border-slate-200">{item.platform || 'Direct'}</span>
                              </td>
                              <td className="px-12 py-10 text-right space-x-3">
                                  <button onClick={() => { 
                                    setEditingItem(item); 
                                    setSelectedImage(null); 
                                    if (item.breakdownSections || item.breakdown_sections) {
                                      setDynamicSections(item.breakdownSections || item.breakdown_sections);
                                    }
                                    setShowForm(true); 
                                  }} className="p-4 text-slate-400 hover:text-blue-600 hover:bg-blue-100 rounded-2xl transition-all border border-slate-200">
                                    <Edit3 className="w-5 h-5" />
                                  </button>
                                  <button onClick={() => handleDelete(item.id, activeTab === 'Our Course Breakdown' ? 'courses' : activeTab === 'Marketplace Management' ? 'affiliates' : 'suggested_courses')} className="p-4 text-slate-400 hover:text-rose-600 hover:bg-rose-100 rounded-2xl transition-all border border-slate-200">
                                    <Trash2 className="w-5 h-5" />
                                  </button>
                              </td>
                            </tr>
                        )) : (
                          <tr><td colSpan={3} className="py-32 text-center text-slate-400 font-black italic">No assets registered</td></tr>
                        )}
                      </tbody>
                  </table>
                </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ManagementDashboard;
