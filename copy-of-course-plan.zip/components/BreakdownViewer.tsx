
import React, { useState } from 'react';
import { Lock, Unlock, ArrowLeft, ShieldCheck, CreditCard, List, Info, Loader2 } from 'lucide-react';
import { Course, UserProfile } from '../types';

interface BreakdownViewerProps {
  course: Course;
  user: UserProfile | null;
  onBack: () => void;
  onPurchase: (courseId: string) => void;
  onOpenAuth: () => void;
}

const BreakdownViewer: React.FC<BreakdownViewerProps> = ({ course, user, onBack, onPurchase, onOpenAuth }) => {
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [activeSection, setActiveSection] = useState(0);
  const hasAccess = user?.purchasedCourseIds?.includes(course.id) || user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN';
  
  const sections = course.breakdownSections || [];

  const handleUnlock = () => {
    if (!user) {
      onOpenAuth();
      return;
    }
    setIsPurchasing(true);
    onPurchase(course.id);
    // Note: Redirection will happen inside App.tsx's handlePurchase
  };

  const scrollToSection = (index: number) => {
    const el = document.getElementById(`section-${index}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setActiveSection(index);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 py-16">
      <button onClick={onBack} className="flex items-center gap-3 text-slate-500 hover:text-cyan-400 font-bold mb-12 transition-colors group text-sm uppercase tracking-widest tracking-wider">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        তালিকায় ফিরুন
      </button>

      {/* Header */}
      <div className="bg-slate-900 rounded-[3.5rem] border border-white/5 shadow-2xl p-10 md:p-14 mb-16 overflow-hidden relative">
        <div className="flex flex-col md:flex-row gap-12 items-center relative z-10">
          <div className="w-full md:w-80 aspect-video rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10">
             <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-3 mb-6">
              <span className="px-5 py-2 bg-white/5 text-slate-400 text-[10px] font-bold rounded-full uppercase tracking-widest border border-white/10">{course.platform}</span>
              {hasAccess && <span className="px-5 py-2 bg-cyan-500/10 text-cyan-400 text-[10px] font-bold rounded-full uppercase tracking-widest flex items-center gap-2 border border-cyan-500/20 shadow-lg shadow-cyan-500/10 tracking-wider"><ShieldCheck className="w-3.5 h-3.5" /> ফুল এক্সেস</span>}
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-6 tracking-tight font-['Outfit'] leading-tight">{course.title}</h1>
            <p className="text-slate-400 font-medium text-lg italic opacity-80 underline decoration-cyan-500/30 decoration-2 tracking-wider">স্মার্ট ডিসিশন নিতে আমাদের এক্সপার্ট এনালাইটিক্যাল ব্রেকডাউন।</p>
          </div>
        </div>
        <div className="absolute -top-32 -right-32 w-80 h-80 bg-cyan-500/5 rounded-full blur-[100px]"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
        {/* Table of Contents (Sidebar) */}
        <aside className="lg:col-span-3 sticky top-36 hidden lg:block">
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-[3rem] border border-white/5 p-8 shadow-xl">
            <div className="flex items-center gap-3 mb-8 text-white font-bold uppercase text-[11px] tracking-[0.2em] tracking-wider">
              <List className="w-4 h-4 text-cyan-400" /> সূচিপত্র (Contents)
            </div>
            <div className="space-y-2">
              {sections.map((section, idx) => (
                <button
                  key={idx}
                  onClick={() => scrollToSection(idx)}
                  className={`w-full text-left px-5 py-4 rounded-2xl text-[13px] font-bold transition-all flex items-center gap-4 ${
                    activeSection === idx 
                      ? 'bg-cyan-400 text-slate-950 shadow-xl cyan-glow' 
                      : 'text-slate-500 hover:bg-white/5 hover:text-white'
                  } tracking-wider`}
                >
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] ${activeSection === idx ? 'bg-slate-950/20' : 'bg-slate-800'}`}>
                    {idx + 1}
                  </span>
                  <span className="truncate">{section.title}</span>
                  {!section.isFree && !hasAccess && <Lock className="w-3.5 h-3.5 ml-auto opacity-40" />}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Content Area */}
        <div className="lg:col-span-9 space-y-16">
          {sections.map((section, idx) => {
            const isLocked = !section.isFree && !hasAccess;
            
            return (
              <div 
                key={idx} 
                id={`section-${idx}`}
                className={`relative group transition-all duration-700 ${isLocked ? 'overflow-hidden' : ''}`}
              >
                <div className={`bg-slate-900 rounded-[3.5rem] border border-white/5 shadow-2xl p-12 md:p-20 ${isLocked ? 'blur-3xl select-none pointer-events-none opacity-40' : ''}`}>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
                    <h2 className="text-3xl font-extrabold text-white flex items-center gap-6 font-['Outfit'] tracking-wider">
                      <span className="w-12 h-12 bg-cyan-400 text-slate-950 rounded-2xl flex items-center justify-center text-sm font-black shadow-lg shadow-cyan-500/20">{idx + 1}</span>
                      {section.title}
                    </h2>
                    {section.isFree ? (
                      <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded-full uppercase tracking-widest border border-emerald-500/20 tracking-wider">
                         <Unlock className="w-3.5 h-3.5" /> ফ্রি সেকশন
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/5 text-slate-500 text-[10px] font-bold rounded-full uppercase tracking-widest border border-white/10 tracking-wider">
                         <Lock className="w-3.5 h-3.5" /> প্রিমিয়াম
                      </span>
                    )}
                  </div>

                  <div className="prose prose-invert max-w-none">
                    <p className="text-slate-300 leading-[2] text-lg font-medium whitespace-pre-wrap tracking-wider">
                      {section.content}
                    </p>
                  </div>
                </div>

                {isLocked && (
                  <div className="absolute inset-0 z-20 flex items-center justify-center p-8 bg-gradient-to-t from-slate-950/95 via-slate-950/80 to-transparent">
                    <div className="bg-slate-900 text-white rounded-[4rem] p-12 md:p-20 text-center max-w-2xl shadow-2xl border border-white/10">
                      <div className="w-20 h-20 bg-cyan-400 text-slate-950 rounded-[2rem] flex items-center justify-center mx-auto mb-10 shadow-2xl cyan-glow">
                        <Lock className="w-8 h-8" />
                      </div>
                      <h3 className="text-4xl font-extrabold mb-6 font-['Outfit'] tracking-wider">বাকি অংশ পড়ার জন্য আনলক করুন!</h3>
                      <p className="text-slate-400 mb-12 text-lg font-medium leading-relaxed tracking-wider">
                        মাত্র <span className="text-cyan-400 font-bold">{course.price} TK</span> পেমেন্ট করে এই ব্রেকডাউনটি সারা জীবনের জন্য আনলক করুন।
                      </p>
                      
                      <button 
                        disabled={isPurchasing}
                        onClick={handleUnlock}
                        className="w-full py-6 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold rounded-full shadow-2xl cyan-glow transition-all active:scale-95 flex items-center justify-center gap-3 text-lg tracking-wider disabled:opacity-50"
                      >
                        {isPurchasing ? (
                          <div className="flex items-center gap-3">
                            <Loader2 className="w-6 h-6 animate-spin" />
                            Gateway-তে পাঠানো হচ্ছে...
                          </div>
                        ) : (
                          <><CreditCard className="w-6 h-6" /> আনলক করুন</>
                        )}
                      </button>
                      <p className="text-[10px] text-slate-500 uppercase font-bold tracking-[0.25em] mt-10 flex items-center justify-center gap-3 tracking-wider">
                        <ShieldCheck className="w-4 h-4 text-cyan-400" /> UddoktaPay-এর মাধ্যমে নিরাপদ পেমেন্ট
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default BreakdownViewer;
