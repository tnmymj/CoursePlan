
import React from 'react';
import CourseCard from './CourseCard';
import { Course } from '../types';
import { Search as SearchIcon, ListFilter } from 'lucide-react';

interface CourseGridProps {
  courses: Course[];
  isFetching?: boolean;
  searchQuery: string;
  onViewBreakdown: (course: Course) => void;
}

const CourseGrid: React.FC<CourseGridProps> = ({ courses, isFetching, searchQuery, onViewBreakdown }) => {
  const filteredCourses = courses.filter(course => 
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.platform.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="py-28 bg-[#020617]" id="breakdowns">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-20 gap-10">
          <div className="max-w-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-1.5 h-10 bg-cyan-400 rounded-full shadow-[0_0_15px_rgba(34,211,238,0.5)]"></div>
              <h2 className="text-4xl font-extrabold text-white tracking-wider font-['Outfit']">কোর্স এনালাইসিস</h2>
            </div>
            <p className="text-slate-400 font-medium leading-relaxed text-lg tracking-wider">
              আমরা বাছাই করেছি দেশের সেরা কিছু প্রিমিয়াম কোর্স। সিদ্ধান্ত নেওয়ার আগে আমাদের এক্সপার্ট এনালাইসিসগুলো বিস্তারিত দেখে নিন।
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex bg-white/5 p-1.5 rounded-full border border-white/10">
               <button className="px-6 py-2.5 bg-cyan-400 text-slate-950 text-[11px] font-bold rounded-full shadow-lg border border-white/10 uppercase tracking-widest">সকল কোর্স</button>
               <button className="px-6 py-2.5 text-slate-400 text-[11px] font-bold hover:text-white transition-colors uppercase tracking-widest">জনপ্রিয়</button>
            </div>
            <button className="p-3.5 bg-slate-900 border border-white/10 text-slate-400 rounded-full hover:text-cyan-400 hover:border-cyan-400/30 transition-all">
              <ListFilter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {isFetching ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-14">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bento-card rounded-[2.5rem] flex flex-col overflow-hidden h-[450px]">
                <div className="skeleton w-full aspect-[16/10] m-4 w-[calc(100%-2rem)] rounded-[1.75rem]"></div>
                <div className="p-8 pt-2 space-y-4">
                  <div className="skeleton h-4 w-1/3 rounded"></div>
                  <div className="skeleton h-8 w-full rounded"></div>
                  <div className="skeleton h-4 w-2/3 rounded"></div>
                  <div className="pt-6 mt-4 border-t border-white/5 flex justify-between">
                    <div className="skeleton h-8 w-24 rounded-full"></div>
                    <div className="skeleton h-8 w-32 rounded-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-14">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} course={course} onView={onViewBreakdown} />
            ))}
          </div>
        ) : (
          <div className="text-center py-40 bg-slate-900/50 rounded-[3.5rem] border border-white/5">
            <div className="mx-auto w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-10 border border-white/10">
               <SearchIcon className="w-10 h-10 text-slate-700" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3 tracking-wider font-['Outfit']">কোন কোর্স পাওয়া যায়নি</h3>
            <p className="text-slate-500 font-medium tracking-wider">ভিন্ন কোনো কি-ওয়ার্ড দিয়ে সার্চ করে দেখুন।</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseGrid;
