
import React from 'react';
import { Star, ArrowRight, Monitor, Layers } from 'lucide-react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onView: (course: Course) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onView }) => {
  return (
    <div className="bento-card group rounded-[2.5rem] flex flex-col overflow-hidden">
      {/* Media Box */}
      <div className="relative aspect-[16/10] overflow-hidden p-4 pb-0">
        <div className="w-full h-full rounded-[1.75rem] overflow-hidden relative border border-white/5">
          <img 
            src={course.thumbnail} 
            alt={course.title} 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
          
          <div className="absolute top-4 right-4">
            <span className="px-4 py-1.5 bg-cyan-400 text-slate-950 text-[11px] font-black rounded-full shadow-lg border border-white/20 uppercase tracking-widest">
              {course.price} TK
            </span>
          </div>
          
          <div className="absolute bottom-4 left-4">
            <span className="flex items-center gap-2 px-3.5 py-1.5 bg-slate-950/60 backdrop-blur-xl text-white text-[9px] font-bold rounded-full uppercase tracking-widest border border-white/10">
              <Monitor className="w-3 h-3 text-cyan-400" />
              {course.platform}
            </span>
          </div>
        </div>
      </div>

      {/* Content Box */}
      <div className="p-8 pt-6 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center text-white">
              <Star className="w-3.5 h-3.5 fill-cyan-400 text-cyan-400" />
              <span className="ml-1.5 text-xs font-bold">{course.rating}</span>
            </div>
            <span className="w-1 h-1 bg-slate-700 rounded-full mx-1"></span>
            <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-[0.2em]">{course.category}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-700">
             <Layers className="w-3.5 h-3.5" />
          </div>
        </div>

        <h3 className="text-xl font-bold text-white mb-4 line-clamp-2 leading-tight group-hover:text-cyan-400 transition-colors font-['Outfit']">
          {course.title}
        </h3>
        
        <p className="text-[13px] text-slate-400 mb-10 line-clamp-2 flex-1 font-medium leading-relaxed">
          {course.description}
        </p>

        {/* Footer Action */}
        <div className="flex items-center justify-between pt-6 border-t border-white/5">
          <div className="flex -space-x-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-950 bg-slate-800 flex items-center justify-center overflow-hidden shadow-sm">
                <img src={`https://i.pravatar.cc/100?img=${i + 40}`} className="w-full h-full object-cover" alt="" />
              </div>
            ))}
          </div>
          <button 
            onClick={() => onView(course)}
            className="flex items-center gap-2.5 px-6 py-2.5 text-[12px] font-bold text-cyan-400 bg-cyan-500/5 rounded-full border border-cyan-500/20 hover:bg-cyan-400 hover:text-slate-950 transition-all active:scale-95"
          >
            Audit Detail
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
