
import React, { useState, useRef } from 'react';
import { 
  FileText, Tag, Sparkles, ShoppingBag, Bell, 
  Settings, Camera, ShieldCheck, Key, 
  LogOut, BookOpen, ArrowRight,
  Mail, Pencil, Save, X, Info, ChevronRight, Shield, Loader2
} from 'lucide-react';
import { DashboardTab, UserProfile, Course, Affiliate } from '../types';
import { supabase } from '../supabase';
import { showToast } from './Toast';

interface DashboardProps {
  user: UserProfile;
  onLogout: () => void;
  onViewCourse: (course: Course) => void;
  allCourses: Course[];
  suggestedCourses: Course[];
  affiliates: Affiliate[];
  onNavigateToManagement?: () => void;
  onUpdateProfile?: (updatedUser: UserProfile) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  user: initialUser, 
  onLogout, 
  onViewCourse, 
  allCourses,
  suggestedCourses,
  affiliates,
  onNavigateToManagement,
  onUpdateProfile
}) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('My CourseBreakDown');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  
  const [tempUser, setTempUser] = useState<UserProfile>(initialUser);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sidebarItems: { name: DashboardTab; icon: React.ReactNode }[] = [
    { name: 'My CourseBreakDown', icon: <FileText className="w-6 h-6" /> },
    { name: 'My Offers', icon: <Tag className="w-6 h-6" /> },
    { name: 'Suggested Course', icon: <Sparkles className="w-6 h-6" /> },
    { name: 'Marketplace', icon: <ShoppingBag className="w-6 h-6" /> },
    { name: 'Updates', icon: <Bell className="w-6 h-6" /> },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      showToast('ছবিটি ২ এমবি-র কম হতে হবে', 'error');
      return;
    }

    setIsUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${initialUser.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });

      if (uploadError) {
        if (uploadError.message.includes('bucket not found')) {
          throw new Error("Supabase-এ 'avatars' নামে কোনো পাবলিক বাকেট পাওয়া যায়নি।");
        }
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      setTempUser({ ...tempUser, avatar: publicUrl });
      showToast('ছবি সিলেক্ট হয়েছে! এবার সেভ বাটনে ক্লিক করুন।', 'success');
    } catch (error: any) {
      showToast('আপলোড এরর: ' + error.message, 'error');
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleProfileSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: tempUser.name,
          avatar: tempUser.avatar,
          bio: tempUser.bio
        })
        .eq('id', tempUser.id);

      if (error) throw error;

      if (onUpdateProfile) {
        onUpdateProfile(tempUser);
      }
      setIsEditingProfile(false);
      showToast('প্রোফাইল আপডেট সফল হয়েছে!', 'success');
    } catch (error: any) {
      showToast('আপডেট ব্যর্থ: ' + error.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('পাসওয়ার্ড পরিবর্তনের লিঙ্ক আপনার ইমেইলে পাঠানো হয়েছে।', 'info');
    setIsChangingPassword(false);
  };

  const purchasedCourses = allCourses.filter(c => initialUser.purchasedCourseIds?.includes(c.id));

  return (
    <div className="max-w-[1700px] mx-auto px-6 lg:px-10 py-12 flex flex-col lg:flex-row gap-8 lg:gap-10 font-['Plus_Jakarta_Sans'] bg-[#020617] min-h-screen">
      
      {/* 1. LEFT SIDEBAR */}
      <aside className="w-full lg:w-[320px] flex-shrink-0">
        <div className="bg-white rounded-[3rem] shadow-[0_30px_60px_rgba(0,0,0,0.3)] p-8 space-y-3 sticky top-28 border border-white/10">
          <div className="px-4 py-8 border-b border-slate-50 mb-6 text-center lg:text-left">
             <span className="text-[12px] font-black text-slate-400 uppercase tracking-[0.4em]">মেম্বার ড্যাশবোর্ড</span>
          </div>
          <nav className="space-y-2.5">
            {sidebarItems.map((item) => (
              <button
                key={item.name}
                onClick={() => setActiveTab(item.name)}
                className={`w-full flex items-center gap-5 px-8 py-5 rounded-[1.8rem] text-[15px] font-black transition-all duration-300 ${
                  activeTab === item.name 
                    ? 'bg-[#2563EB] text-white shadow-2xl shadow-blue-500/40 -translate-y-1' 
                    : 'text-[#64748B] hover:bg-slate-50 hover:text-[#1E293B]'
                }`}
              >
                <div className={`${activeTab === item.name ? 'text-white' : 'text-[#94A3B8]'}`}>
                  {item.icon}
                </div>
                {item.name}
              </button>
            ))}
          </nav>
          
          <div className="pt-10 mt-10 border-t border-slate-50">
            {onNavigateToManagement && (
              <button 
                onClick={onNavigateToManagement}
                className="w-full flex items-center gap-5 px-8 py-5 rounded-[1.8rem] text-[15px] font-black text-blue-600 hover:bg-blue-50 transition-all group mb-2"
              >
                <Shield className="w-6 h-6 transition-transform group-hover:scale-110" />
                ম্যানেজমেন্ট প্যানেল
              </button>
            )}
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-5 px-8 py-5 rounded-[1.8rem] text-[15px] font-black text-[#F43F5E] hover:bg-rose-50 transition-all group"
            >
              <LogOut className="w-6 h-6 transition-transform group-hover:-translate-x-1" />
              লগ-আউট করুন
            </button>
          </div>
        </div>
      </aside>

      {/* 2. MAIN CONTENT AREA */}
      <main className="flex-1 min-w-0">
        <div className="bg-white rounded-[3.5rem] shadow-[0_30px_60px_rgba(0,0,0,0.2)] p-12 lg:p-16 min-h-[900px] border border-white/10 relative overflow-hidden">
          <div className="mb-14 flex items-center justify-between">
            <div>
              <h1 className="text-[42px] font-black text-[#1E293B] tracking-tight leading-none mb-3 font-['Outfit']">
                {activeTab}
              </h1>
              <div className="flex items-center gap-3">
                 <span className="flex h-3 w-3 rounded-full bg-blue-500 animate-pulse"></span>
                 <p className="text-[#94A3B8] text-[12px] font-black uppercase tracking-[0.3em]">অ্যাক্টিভ মেম্বারশিপ: {initialUser.role}</p>
              </div>
            </div>
          </div>

          {activeTab === 'My CourseBreakDown' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {purchasedCourses.length > 0 ? purchasedCourses.map(course => (
                 <div key={course.id} className="group bg-[#F8FAFC] rounded-[3rem] border border-[#F1F5F9] p-10 hover:bg-white hover:border-blue-200 transition-all duration-500 shadow-sm hover:shadow-2xl">
                    <div className="flex items-start gap-8 mb-12">
                       <img src={course.thumbnail} className="w-28 h-28 rounded-[2rem] object-cover border-8 border-white shadow-xl" alt="" />
                       <div className="flex-1">
                          <span className="text-[11px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1.5 rounded-lg">{course.platform}</span>
                          <h3 className="text-xl font-bold text-[#1E293B] line-clamp-2 mt-4 leading-tight font-['Outfit']">{course.title}</h3>
                       </div>
                    </div>
                    <button onClick={() => onViewCourse(course)} className="w-full py-5 bg-white border border-[#E2E8F0] rounded-2xl text-[14px] font-black text-[#64748B] hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all flex items-center justify-center gap-3 shadow-sm active:scale-95">
                      ব্রেকডাউন দেখুন <ArrowRight className="w-5 h-5" />
                    </button>
                 </div>
              )) : (
                <div className="col-span-full py-48 text-center border-4 border-dashed border-[#F1F5F9] rounded-[4rem] bg-slate-50/50">
                   <div className="w-32 h-32 bg-white rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 border border-slate-100 shadow-xl">
                      <BookOpen className="w-12 h-12 text-[#E2E8F0]" />
                   </div>
                   <h3 className="text-3xl font-black text-[#1E293B] mb-4 font-['Outfit']">কোনো ব্রেকডাউন কেনা নেই</h3>
                   <p className="text-[#94A3B8] mb-14 max-w-sm mx-auto font-medium text-lg italic leading-relaxed">আপনি এখনো কোনো প্রিমিয়াম অডিট আনলক করেননি। আজই শুরু করুন আপনার লার্নিং জার্নি!</p>
                   <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="px-16 py-6 bg-[#2563EB] text-white font-black rounded-[2rem] shadow-[0_20px_40px_rgba(37,99,235,0.3)] text-xs uppercase tracking-[0.3em] hover:scale-105 transition-transform active:scale-95">অডিট খুঁজুন</button>
                </div>
              )}
            </div>
          )}

          {activeTab !== 'My CourseBreakDown' && (
            <div className="py-48 text-center">
              <div className="w-28 h-28 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 border border-slate-100 shadow-inner">
                 {sidebarItems.find(i => i.name === activeTab)?.icon}
              </div>
              <h2 className="text-3xl font-black text-[#1E293B] mb-4 font-['Outfit']">ফিচারটি শীঘ্রই আসছে</h2>
              <p className="text-[#94A3B8] font-medium text-lg max-w-md mx-auto italic">আমরা এই সেকশনটি নিয়ে কাজ করছি। নতুন নতুন অফার আর আপডেটের জন্য সাথেই থাকুন।</p>
            </div>
          )}
        </div>
      </main>

      {/* 3. RIGHT SIDEBAR - PROFILE HUB */}
      <aside className="w-full lg:w-[450px] flex-shrink-0">
        <div className="space-y-8 sticky top-28">
          
          <div className="bg-white rounded-[3.5rem] shadow-[0_30px_60px_rgba(0,0,0,0.2)] p-12 flex flex-col border border-white/10 relative overflow-hidden group">
            <div className="flex justify-between items-center mb-10 w-full">
               <span className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em]">আপনার প্রোফাইল</span>
               {!isEditingProfile ? (
                 <button 
                  onClick={() => {
                    setTempUser(initialUser);
                    setIsEditingProfile(true);
                  }} 
                  className="p-3 bg-slate-50 rounded-xl text-slate-400 hover:bg-blue-600 hover:text-white transition-all shadow-sm flex items-center gap-2 text-xs font-bold"
                 >
                   <Pencil className="w-3 h-3" /> এডিট করুন
                 </button>
               ) : (
                 <div className="flex gap-2">
                    <button onClick={() => setIsEditingProfile(false)} className="p-3 bg-rose-50 rounded-xl text-rose-500 hover:bg-rose-500 hover:text-white transition-all shadow-sm">
                      <X className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={handleProfileSave} 
                      disabled={isSaving || isUploading}
                      className="p-3 px-5 bg-emerald-50 rounded-xl text-emerald-600 hover:bg-emerald-600 hover:text-white transition-all shadow-sm flex items-center gap-2 font-black text-xs disabled:opacity-50"
                    >
                      {isSaving ? 'সেভ হচ্ছে...' : <><Save className="w-4 h-4" /> সেভ করুন</>}
                    </button>
                 </div>
               )}
            </div>

            <div className="flex flex-col items-center w-full">
              <div className="relative mb-10">
                <div 
                  className={`w-44 h-44 rounded-[3.5rem] overflow-hidden border-[10px] border-slate-50 shadow-2xl ring-2 ring-blue-50 p-1 transition-all duration-500 ${isEditingProfile ? 'cursor-pointer hover:scale-105 active:scale-95' : ''}`}
                  onClick={() => isEditingProfile && fileInputRef.current?.click()}
                >
                  <img src={tempUser.avatar} alt="Avatar" className={`w-full h-full object-cover rounded-[2.8rem] ${isUploading ? 'opacity-30 blur-sm' : ''}`} />
                  {isUploading && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                    </div>
                  )}
                </div>
                {isEditingProfile && (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-2 -right-2 p-4 bg-[#2563EB] text-white rounded-[1.5rem] shadow-2xl border-4 border-white hover:bg-blue-700 transition-colors"
                  >
                    <Camera className="w-6 h-6" />
                  </button>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleFileUpload}
                />
              </div>
              
              <div className="text-center w-full space-y-8">
                {isEditingProfile ? (
                  <div className="space-y-5 w-full text-left bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100">
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">পুরো নাম</label>
                        <input 
                          value={tempUser.name} 
                          onChange={(e) => setTempUser({...tempUser, name: e.target.value})}
                          placeholder="আপনার নাম লিখুন"
                          className="w-full px-6 py-4 bg-white border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 transition-all font-bold text-slate-900 shadow-sm"
                        />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">বায়ো (Bio)</label>
                        <textarea 
                          value={tempUser.bio || ''} 
                          onChange={(e) => setTempUser({...tempUser, bio: e.target.value})}
                          placeholder="আপনার সম্পর্কে কিছু বলুন..."
                          className="w-full px-6 py-4 bg-white border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 transition-all font-medium text-slate-900 h-28 resize-none shadow-sm"
                        />
                     </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h2 className="text-[32px] font-black text-[#1E293B] tracking-tight mb-2 font-['Outfit']">{initialUser.name}</h2>
                    {initialUser.bio ? (
                      <p className="text-[#64748B] text-[15px] font-medium leading-relaxed italic px-4 max-w-sm mx-auto">
                        "{initialUser.bio}"
                      </p>
                    ) : (
                      <button onClick={() => setIsEditingProfile(true)} className="text-blue-500 text-[13px] font-bold hover:underline">
                        + বায়ো যোগ করুন
                      </button>
                    )}
                    <p className="text-[#94A3B8] text-[14px] font-medium flex items-center justify-center gap-2 pt-2">
                      <Mail className="w-4 h-4 text-blue-300" /> {initialUser.email}
                    </p>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-[#FFF7ED] p-6 rounded-[1.8rem] border border-[#FFEDD5] text-center shadow-sm">
                     <p className="text-[10px] font-black text-[#EA580C] uppercase tracking-widest mb-1.5 opacity-60">রোল</p>
                     <p className="text-[15px] font-black text-[#EA580C] uppercase">{initialUser.role}</p>
                  </div>
                  <div className="bg-[#EFF6FF] p-6 rounded-[1.8rem] border border-[#DBEAFE] text-center shadow-sm">
                     <p className="text-[10px] font-black text-[#2563EB] uppercase tracking-widest mb-1.5 opacity-60">অডিট এক্সেস</p>
                     <p className="text-[15px] font-black text-[#2563EB] uppercase">{purchasedCourses.length} টি</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#1E293B] rounded-[3.5rem] shadow-[0_30px_60px_rgba(0,0,0,0.3)] p-12 text-white relative overflow-hidden group min-h-[400px]">
            <div className="relative z-10">
               <div className="flex items-center gap-5 mb-10">
                 <div className="w-16 h-16 bg-white/10 rounded-[1.5rem] flex items-center justify-center border border-white/5 shadow-inner">
                   <ShieldCheck className="w-8 h-8 text-blue-400" />
                 </div>
                 <h3 className="text-xl font-black font-['Outfit'] tracking-tight">সিকিউরিটি</h3>
               </div>
               
               {!isChangingPassword ? (
                 <div className="space-y-4">
                    <button 
                      onClick={() => setIsChangingPassword(true)}
                      className="w-full flex items-center justify-between p-6 bg-white/5 rounded-[1.5rem] hover:bg-white/10 transition-all group/btn border border-white/5"
                    >
                       <div className="flex items-center gap-5">
                          <Key className="w-6 h-6 text-blue-400 opacity-60 transition-opacity" />
                          <span className="text-[15px] font-bold">পাসওয়ার্ড পরিবর্তন</span>
                       </div>
                       <ChevronRight className="w-5 h-5 text-slate-500 group-hover/btn:translate-x-1.5 transition-transform" />
                    </button>
                 </div>
               ) : (
                 <form onSubmit={handlePasswordChangeSubmit} className="space-y-6">
                    <div className="space-y-2">
                       <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">বর্তমান পাসওয়ার্ড</label>
                       <input type="password" required className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500 transition-all text-white" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">নতুন পাসওয়ার্ড</label>
                       <input type="password" required className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-blue-500 transition-all text-white" />
                    </div>
                    <div className="flex gap-4">
                       <button type="button" onClick={() => setIsChangingPassword(false)} className="flex-1 py-4 bg-white/5 rounded-2xl font-bold text-xs">বাতিল</button>
                       <button type="submit" className="flex-1 py-4 bg-blue-600 rounded-2xl font-bold text-xs">আপডেট</button>
                    </div>
                 </form>
               )}
            </div>
          </div>
        </div>
      </aside>

    </div>
  );
};

export default Dashboard;
