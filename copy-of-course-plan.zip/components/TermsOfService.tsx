
import React from 'react';
import { FileText, ArrowLeft, CheckCircle, AlertCircle, Info, Mail } from 'lucide-react';

interface TermsOfServiceProps {
  onBack: () => void;
}

const TermsOfService: React.FC<TermsOfServiceProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-[#020617] py-24">
      <div className="max-w-4xl mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 text-slate-500 hover:text-cyan-400 font-bold mb-12 transition-colors group text-sm uppercase tracking-widest tracking-wider">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          ফিরে যান
        </button>

        <div className="bg-slate-900/50 backdrop-blur-xl rounded-[3rem] border border-white/5 shadow-2xl p-10 md:p-20 overflow-hidden relative">
          <div className="relative z-10">
            <div className="w-16 h-16 bg-blue-500/10 text-blue-400 rounded-2xl flex items-center justify-center mb-10 border border-blue-500/20">
              <FileText className="w-8 h-8" />
            </div>
            
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-8 tracking-tight font-['Outfit'] tracking-wider">টার্মস অব সার্ভিস</h1>
            <p className="text-slate-400 text-lg mb-12 font-medium leading-relaxed italic border-l-4 border-blue-500/50 pl-6 tracking-wider">
              "Course Plan ব্যবহারের মাধ্যমে আপনি আমাদের সকল নিয়ম ও শর্তাবলী মেনে নিচ্ছেন। অনুগ্রহ করে নিচের শর্তগুলো মনোযোগ দিয়ে পড়ুন।"
            </p>

            <div className="space-y-12">
              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <CheckCircle className="w-5 h-5 text-cyan-400" /> ১. সাধারণ ব্যবহার
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  কোর্স প্ল্যান একটি লার্নিং গাইডেন্স প্ল্যাটফর্ম। আমরা বিভিন্ন অনলাইন কোর্সের অডিট এবং বিশ্লেষণ প্রদান করি। আমাদের সার্ভিস শুধুমাত্র ব্যক্তিগত এবং শিক্ষামূলক উদ্দেশ্যে ব্যবহার করা যাবে।
                </p>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <AlertCircle className="w-5 h-5 text-cyan-400" /> ২. পেমেন্ট ও অ্যাক্সেস
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  পছন্দসই কোর্স ব্রেকডাউন দেখার জন্য নির্ধারিত ফি প্রদান করতে হবে। পেমেন্ট সফল হওয়ার পর আপনি সংশ্লিষ্ট কন্টেন্টের লাইফটাইম অ্যাক্সেস পাবেন। আমাদের কন্টেন্ট কোনোভাবেই অনুমতি ছাড়া কপি বা বাণিজ্যিক উদ্দেশ্যে পুনঃপ্রকাশ করা সম্পূর্ণ নিষিদ্ধ।
                </p>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <Info className="w-5 h-5 text-cyan-400" /> ৩. রিফান্ড পলিসি
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  যেহেতু আমাদের সার্ভিসটি ডিজিটাল কন্টেন্ট ভিত্তিক, একবার পেমেন্ট সম্পন্ন হয়ে কন্টেন্ট অ্যাক্সেস পেয়ে গেলে সাধারণত কোনো রিফান্ড প্রদান করা হয় না। তবে পেমেন্ট সংক্রান্ত টেকনিক্যাল সমস্যার ক্ষেত্রে আমরা সর্বোচ্চ সহযোগিতা করব।
                </p>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <AlertCircle className="w-5 h-5 text-cyan-400" /> ৪. দায়বদ্ধতা (Liability)
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  আমরা আমাদের বিশ্লেষণের নির্ভুলতা নিশ্চিত করার চেষ্টা করি। তবে আমরা কোনো থার্ড-পার্টি কোর্সের মানের জন্য সরাসরি দায়ী নই। আমাদের দেওয়া সাজেশন এবং বিশ্লেষণ ব্যবহারকারীর সিদ্ধান্ত গ্রহণের সহায়িকা মাত্র।
                </p>
              </section>

              <section className="bg-slate-800/50 p-10 rounded-[2.5rem] border border-white/5">
                <div className="flex items-center gap-3 text-cyan-400 font-bold text-xl mb-6 tracking-wider">
                  <Mail className="w-6 h-6" /> যোগাযোগ
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium mb-6 tracking-wider">
                  আমাদের শর্তাবলী সংক্রান্ত কোনো প্রশ্ন থাকলে ইমেইল করুন:
                </p>
                <a 
                  href="mailto:coursesplan@gmail.com" 
                  className="inline-flex items-center px-8 py-4 bg-cyan-400 text-slate-950 font-bold rounded-2xl hover:bg-cyan-300 transition-all cyan-glow tracking-wider"
                >
                  coursesplan@gmail.com
                </a>
              </section>
            </div>
          </div>

          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
        </div>
        
        <div className="mt-16 text-center text-slate-600 text-xs font-bold uppercase tracking-[0.3em]">
          Effective From: May 2025
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
