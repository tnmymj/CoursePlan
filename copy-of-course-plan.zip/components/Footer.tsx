
import React from 'react';
import { BookOpen, Facebook, Youtube, Instagram, Mail, MessageSquare } from 'lucide-react';
import { NavItem } from '../types';

interface FooterProps {
  setActiveNav?: (nav: NavItem) => void;
}

const Footer: React.FC<FooterProps> = ({ setActiveNav }) => {
  return (
    <footer className="bg-[#020617] text-slate-500 pt-32 pb-16 border-t border-white/5 relative overflow-hidden">
      {/* Decorative Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-[300px] bg-cyan-500/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-16 mb-24">
          
          {/* Brand Column */}
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3.5 mb-10">
              <div className="bg-cyan-500 p-2 rounded-xl shadow-lg shadow-cyan-500/20">
                < BookOpen className="w-6 h-6 text-slate-950" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight font-['Outfit']">
                Course <span className="text-cyan-400">Plan</span>
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-10 max-w-sm font-medium text-[15px] tracking-wider">
              কোর্স প্ল্যান আপনাকে অনলাইন কোর্স কেনার আগে সঠিক সিদ্ধান্ত নিতে সাহায্য করে। আমরা বিভিন্ন প্রিমিয়াম কোর্সের বাস্তব এবং নিরপেক্ষ বিশ্লেষণ প্রদান করি যাতে আপনার সময় এবং টাকা দুটিরই সঠিক ব্যবহার হয়।
            </p>
            <div className="flex items-center gap-5">
              {[
                { Icon: Facebook, link: "https://www.facebook.com/courseplan", color: "hover:bg-[#1877F2]" },
                { Icon: Youtube, link: "#", color: "hover:bg-[#FF0000]" },
                { Icon: Instagram, link: "#", color: "hover:bg-[#E4405F]" },
                { Icon: MessageSquare, link: "#", color: "hover:bg-cyan-500" }
              ].map(({ Icon, link, color }, i) => (
                <a 
                  key={i} 
                  href={link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-11 h-11 flex items-center justify-center bg-white/5 rounded-full text-slate-400 hover:text-white transition-all duration-300 border border-white/5 ${color}`}
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation Column */}
          <div className="lg:col-span-2">
            <h4 className="text-white font-bold mb-10 uppercase text-[11px] tracking-[0.2em] opacity-60">Navigation</h4>
            <ul className="space-y-5 text-[14px] font-semibold">
              <li><button onClick={() => setActiveNav?.('Home')} className="hover:text-cyan-400 transition-colors">Home</button></li>
              <li><button onClick={() => setActiveNav?.('Course Breakdown')} className="hover:text-cyan-400 transition-colors">Course Breakdown</button></li>
              <li><button onClick={() => setActiveNav?.('Marketplace')} className="hover:text-cyan-400 transition-colors">Marketplace</button></li>
            </ul>
          </div>

          {/* Support Column */}
          <div className="lg:col-span-2">
            <h4 className="text-white font-bold mb-10 uppercase text-[11px] tracking-[0.2em] opacity-60">Support</h4>
            <ul className="space-y-5 text-[14px] font-semibold">
              <li><button onClick={() => setActiveNav?.('Privacy Policy')} className="hover:text-cyan-400 transition-colors text-left">Privacy Policy</button></li>
              <li><button onClick={() => setActiveNav?.('Terms of Service')} className="hover:text-cyan-400 transition-colors text-left">Terms of Service</button></li>
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="lg:col-span-3">
            <h4 className="text-white font-bold mb-10 uppercase text-[11px] tracking-[0.2em] opacity-60">Contact</h4>
            <ul className="space-y-6">
              <li className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center flex-shrink-0 border border-white/5">
                  <Mail className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-[14px]">
                  <p className="text-white font-bold mb-0.5 tracking-wider">ইমেইল করুন</p>
                  <a href="mailto:coursesplan@gmail.com" className="text-slate-500 hover:text-cyan-400 transition-colors">coursesplan@gmail.com</a>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center flex-shrink-0 border border-white/5">
                  <Facebook className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-[14px]">
                  <p className="text-white font-bold mb-0.5 tracking-wider">ফেসবুক পেজ</p>
                  <a href="https://www.facebook.com/courseplan" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-cyan-400 transition-colors">facebook.com/courseplan</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 text-[11px] font-bold uppercase tracking-[0.2em]">
          <p className="text-slate-600 tracking-wider">© 2025 Course Plan. The right decision is the key to success.</p>
          <div className="flex items-center gap-10">
            <span className="text-slate-700 hidden sm:inline">Made with ❤️ for Learners</span>
            <div className="flex gap-6">
              <button onClick={() => setActiveNav?.('Privacy Policy')} className="text-slate-600 hover:text-white transition-colors">Privacy</button>
              <button onClick={() => setActiveNav?.('Terms of Service')} className="text-slate-600 hover:text-white transition-colors">Terms</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
