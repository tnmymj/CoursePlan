
import React, { useState } from 'react';
import { ExternalLink, LayoutGrid, Search, Sparkles, Monitor, GraduationCap } from 'lucide-react';
import { Affiliate } from '../types';

interface MarketplaceProps { 
  affiliates: Affiliate[];
  isFetching?: boolean;
}

const Marketplace: React.FC<MarketplaceProps> = ({ affiliates, isFetching }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [viewType, setViewType] = useState<'ALL' | 'PLATFORM' | 'COURSE'>('ALL');

  const categories = ['All', 'Development', 'Design', 'Marketing', 'Academic', 'Freelancing', 'Job Prep'];

  const filteredItems = affiliates.filter(aff => {
    const matchesSearch = aff.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         aff.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || aff.categories.includes(selectedCategory);
    const matchesType = viewType === 'ALL' || aff.type === viewType;
    return matchesSearch && matchesCategory && matchesType;
  });

  return (
    <div className="bg-[#020617] min-h-screen">
      {/* Hero Header */}
      <section className="bg-slate-950 border-b border-white/5 pt-28 pb-24 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10 text-center">
          <div className="inline-flex items-center gap-3 px-5 py-2 bg-white/5 text-slate-400 rounded-full text-[11px] font-bold uppercase tracking-[0.2em] mb-10 border border-white/10 shadow-xl">
            <LayoutGrid className="w-4 h-4 text-cyan-400" /> Unified Ecosystem
          </div>
          <h1 className="text-5xl sm:text-[72px] font-extrabold text-white mb-10 tracking-tighter font-['Outfit'] tracking-wider">
            Explore the <span className="text-cyan-400 italic">Marketplace</span>
          </h1>
          <p className="text-xl sm:text-2xl text-slate-400 max-w-3xl mx-auto font-medium leading-relaxed italic opacity-80 tracking-wider">
            We have curated the best e-learning platforms and top-rated courses. Enroll directly through our verified partner links.
          </p>

          {/* Search & Filter Bar */}
          <div className="mt-16 max-w-5xl mx-auto space-y-8">
            <div className="bg-slate-900 p-4 rounded-[3.5rem] shadow-2xl border border-white/10 flex flex-col md:flex-row gap-6">
              <div className="flex-1 relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Search platforms or courses..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-16 pr-8 py-5 bg-white/5 rounded-full border-none outline-none font-bold text-white placeholder:text-slate-700 tracking-wider"
                />
              </div>
              <div className="flex bg-white/5 p-2 rounded-full gap-2 border border-white/10">
                {(['ALL', 'PLATFORM', 'COURSE'] as const).map(type => (
                  <button 
                    key={type}
                    onClick={() => setViewType(type)}
                    className={`px-8 py-4 rounded-full text-[11px] font-bold uppercase tracking-widest transition-all ${
                      viewType === type ? 'bg-cyan-400 text-slate-950 shadow-xl cyan-glow' : 'text-slate-500 hover:text-white'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex overflow-x-auto gap-3 p-2 no-scrollbar justify-center">
              {categories.map(cat => (
                <button 
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-8 py-3 rounded-full text-[11px] font-bold uppercase tracking-widest transition-all whitespace-nowrap border-2 ${
                    selectedCategory === cat 
                    ? 'bg-white border-white text-slate-950 shadow-xl' 
                    : 'bg-transparent border-white/10 text-slate-500 hover:border-cyan-400/30 hover:text-cyan-400'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="absolute top-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px]"></div>
      </section>

      {/* Grid Content */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-14">
          {isFetching ? (
            [1, 2, 3].map(i => (
              <div key={i} className="bento-card rounded-[3.5rem] p-10 h-72 flex flex-col justify-between">
                <div className="flex justify-between">
                   <div className="skeleton w-16 h-16 rounded-2xl"></div>
                   <div className="skeleton w-24 h-6 rounded-full"></div>
                </div>
                <div className="skeleton w-full h-8 rounded"></div>
                <div className="skeleton w-2/3 h-4 rounded"></div>
                <div className="flex justify-between pt-6 border-t border-white/5">
                   <div className="skeleton w-24 h-4 rounded"></div>
                   <div className="skeleton w-32 h-10 rounded-full"></div>
                </div>
              </div>
            ))
          ) : filteredItems.map((item) => (
            <div key={item.id} className="bento-card group rounded-[3.5rem] p-10 flex flex-col relative overflow-hidden">
              <div className="flex items-start justify-between mb-10 relative z-10">
                <div className="w-20 h-20 rounded-[2rem] bg-white/5 border border-white/10 p-4 group-hover:bg-white/10 transition-all duration-500">
                  <img src={item.logo} alt={item.name} className="w-full h-full object-contain grayscale group-hover:grayscale-0 opacity-40 group-hover:opacity-100 transition-all" />
                </div>
                <div className="flex flex-col items-end gap-3">
                  <span className={`px-4 py-1.5 text-[9px] font-bold uppercase tracking-[0.2em] rounded-full border ${
                    item.type === 'PLATFORM' ? 'bg-cyan-400/10 text-cyan-400 border-cyan-400/20' : 'bg-white/5 text-slate-500 border-white/10'
                  }`}>
                    {item.type === 'PLATFORM' ? 'Academy' : 'Course'}
                  </span>
                </div>
              </div>

              <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors relative z-10 font-['Outfit']">
                {item.name}
              </h3>
              
              <p className="text-slate-500 text-[15px] leading-relaxed mb-10 flex-1 font-medium relative z-10">
                {item.description}
              </p>

              <div className="pt-8 border-t border-white/5 flex items-center justify-between relative z-10">
                <div className="flex items-center gap-3 text-slate-700">
                  {item.type === 'PLATFORM' ? <Monitor className="w-4 h-4 text-cyan-400" /> : <GraduationCap className="w-4 h-4 text-cyan-400" />}
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 tracking-wider">
                    Verified Link
                  </span>
                </div>
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="px-8 py-3.5 bg-slate-950 text-white text-[11px] font-bold rounded-full border border-white/10 hover:bg-cyan-400 hover:text-slate-950 transition-all shadow-xl active:scale-95 flex items-center gap-3 uppercase tracking-widest tracking-wider"
                >
                  Visit Site <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="absolute bottom-0 left-0 w-0 h-1 bg-cyan-400 transition-all duration-700 group-hover:w-full"></div>
            </div>
          ))}

          {!isFetching && (
            <div className="bg-cyan-400 rounded-[3.5rem] p-12 flex flex-col items-center justify-center text-center text-slate-950 relative overflow-hidden group shadow-2xl cyan-glow">
              <div className="relative z-10">
                <div className="w-24 h-24 bg-slate-950/10 rounded-[2.5rem] flex items-center justify-center mb-8 mx-auto">
                  <Sparkles className="w-10 h-10 text-slate-950 opacity-60" />
                </div>
                <h3 className="text-3xl font-bold mb-6 font-['Outfit'] leading-tight tracking-wider">Missing Something?</h3>
                <p className="text-slate-950/60 text-[15px] mb-12 font-medium leading-relaxed italic tracking-wider">
                  Which platform or course should we add next? Let us know!
                </p>
                <button className="w-full py-5 bg-slate-950 text-white font-bold rounded-full shadow-2xl hover:scale-105 transition-all active:scale-95 uppercase tracking-widest text-xs tracking-wider">
                  Request Addition
                </button>
              </div>
              <div className="absolute -top-10 -right-10 w-48 h-48 bg-white/20 rounded-full blur-[80px]"></div>
            </div>
          )}
        </div>

        {!isFetching && filteredItems.length === 0 && (
          <div className="py-40 text-center bg-slate-900/30 rounded-[4rem] border-2 border-dashed border-white/5">
            <h3 className="text-xl font-bold text-slate-700 uppercase tracking-[0.3em]">No results found</h3>
          </div>
        )}
      </section>
    </div>
  );
};

export default Marketplace;
