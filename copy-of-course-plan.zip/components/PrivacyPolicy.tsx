
import React from 'react';
import { Shield, ArrowLeft, Mail, Lock, Eye, Cookie } from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-[#020617] py-24">
      <div className="max-w-4xl mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 text-slate-500 hover:text-cyan-400 font-bold mb-12 transition-colors group text-sm uppercase tracking-widest tracking-wider">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          ফিরে যান
        </button>

        <div className="bg-slate-900/50 backdrop-blur-xl rounded-[3rem] border border-white/5 shadow-2xl p-10 md:p-20 overflow-hidden relative">
          <div className="relative z-10">
            <div className="w-16 h-16 bg-cyan-500/10 text-cyan-400 rounded-2xl flex items-center justify-center mb-10 border border-cyan-500/20">
              <Shield className="w-8 h-8" />
            </div>
            
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-8 tracking-tight font-['Outfit'] tracking-wider">প্রাইভেসি পলিসি</h1>
            <p className="text-slate-400 text-lg mb-12 font-medium leading-relaxed italic border-l-4 border-cyan-500/50 pl-6 tracking-wider">
              "Course Plan আপনার গোপনীয়তাকে গুরুত্ব দিয়ে পরিচালিত। আপনার তথ্যের সুরক্ষা নিশ্চিত করাই আমাদের প্রধান লক্ষ্য।"
            </p>

            <div className="space-y-12">
              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <Lock className="w-5 h-5 text-cyan-400" /> তথ্য সংগ্রহ
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  আমরা শুধুমাত্র প্রয়োজনীয় তথ্যই সংগ্রহ করি, যেমন নাম, ইমেইল ও লগইন তথ্য, যাতে আপনি আমাদের সার্ভিস ব্যবহার করতে পারেন। আপনার ব্যক্তিগত তথ্যের নিরাপত্তা আমাদের কাছে সবচেয়ে বড় অগ্রাধিকার।
                </p>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <Eye className="w-5 h-5 text-cyan-400" /> পেমেন্ট এবং নিরাপত্তা
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  পেমেন্টের তথ্য সরাসরি আমরা সংরক্ষণ করি না; সব পেমেন্ট নিরাপদ তৃতীয়-পক্ষ পেমেন্ট গেটওয়ের মাধ্যমে সম্পন্ন হয়। আমরা আপনার তথ্য কোনো তৃতীয় পক্ষকে বিক্রি বা শেয়ার করি না।
                </p>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-3 text-white font-bold text-xl mb-4 tracking-wider">
                  <Cookie className="w-5 h-5 text-cyan-400" /> কুকিজ ব্যবহার
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium tracking-wider">
                  Cookies ব্যবহার করা হতে পারে আমাদের ওয়েবসাইটের অভিজ্ঞতা উন্নত করার জন্য এবং আপনার ব্রাউজিংকে আরও সহজতর করার জন্য।
                </p>
              </section>

              <section className="bg-slate-800/50 p-10 rounded-[2.5rem] border border-white/5">
                <div className="flex items-center gap-3 text-cyan-400 font-bold text-xl mb-6 tracking-wider">
                  <Mail className="w-6 h-6" /> যোগাযোগ করুন
                </div>
                <p className="text-slate-300 leading-[1.8] font-medium mb-6 tracking-wider">
                  আমাদের প্রাইভেসি পলিসি নিয়ে কোনো প্রশ্ন বা জিজ্ঞাসা থাকলে সরাসরি আমাদের ইমেইলে যোগাযোগ করুন:
                </p>
                <a 
                  href="mailto:coursesplan@gmail.com" 
                  className="inline-flex items-center px-8 py-4 bg-cyan-400 text-slate-950 font-bold rounded-2xl hover:bg-cyan-300 transition-all cyan-glow tracking-wider"
                >
                  coursesplan@gmail.com
                </a>
              </section>
            </div>
          </div>

          <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2"></div>
        </div>
        
        <div className="mt-16 text-center text-slate-600 text-xs font-bold uppercase tracking-[0.3em]">
          Last Updated: May 2025
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
