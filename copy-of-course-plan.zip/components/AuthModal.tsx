
import React, { useState } from 'react';
import { X, Mail, Lock, ArrowRight, Eye, EyeOff, ChevronLeft, Chrome } from 'lucide-react';
import { supabase } from '../supabase';
import { showToast } from './Toast';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AuthView = 'login' | 'signup' | 'forgot-password';

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [view, setView] = useState<AuthView>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const validateEmail = (email: string) => {
    return String(email)
      .toLowerCase()
      .match(/^(([^<>()[\]\\.,;s@"]+(\.[^<>()[\]\\.,;s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  };

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
    } catch (error: any) {
      showToast(error.message || 'Google login failed', 'error');
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateEmail(email)) {
      showToast('Please enter a valid email address', 'error');
      return;
    }

    if (password.length < 6) {
      showToast('Password must be at least 6 characters', 'error');
      return;
    }

    setIsLoading(true);

    try {
      if (view === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        showToast('Login successful', 'success');
        onClose();
      } else if (view === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        showToast('Account created. Please check your email.', 'success');
        onClose();
      }
    } catch (error: any) {
      showToast(error.message || 'Authentication failed', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in duration-500">
      <div className="bg-[#020617] w-full max-w-[440px] rounded-[3rem] shadow-[0_0_100px_rgba(0,0,0,0.5)] border border-white/5 overflow-hidden relative animate-in zoom-in-95 duration-500">
        
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 p-2 text-slate-600 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-12 md:p-14">
          <div className="text-center mb-10">
            <h2 className="text-4xl font-black text-white mb-3 tracking-tight font-['Outfit']">
              {view === 'login' ? 'Welcome Back' : view === 'signup' ? 'Join Us' : 'Recover Key'}
            </h2>
            <p className="text-slate-500 text-sm font-medium italic tracking-wider">
              {view === 'login' ? 'Access your audit terminal' : view === 'signup' ? 'Initialize your membership' : 'Reset your master password'}
            </p>
          </div>

          {/* OAuth Provider */}
          <div className="mb-8">
            <button 
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-4 bg-white hover:bg-slate-100 text-slate-900 font-bold rounded-2xl transition-all active:scale-95 flex items-center justify-center gap-3 text-sm border border-white/10 shadow-xl disabled:opacity-50"
            >
              <Chrome className="w-5 h-5" />
              Continue with Google
            </button>
            <div className="relative flex items-center justify-center mt-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/5"></div>
              </div>
              <span className="relative px-4 bg-[#020617] text-[10px] font-black text-slate-700 uppercase tracking-[0.3em]">OR USE EMAIL</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="group relative">
              <Mail className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600 group-focus-within:text-cyan-400 transition-colors" />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address" 
                required
                className="w-full pl-14 pr-8 py-5 bg-slate-900/50 border border-white/5 rounded-2xl outline-none focus:border-cyan-500/30 focus:bg-slate-900 transition-all font-bold text-white placeholder:text-slate-700 tracking-wider"
              />
            </div>

            <div className="group relative">
              <Lock className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600 group-focus-within:text-cyan-400 transition-colors" />
              <input 
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password" 
                required
                className="w-full pl-14 pr-14 py-5 bg-slate-900/50 border border-white/5 rounded-2xl outline-none focus:border-cyan-500/30 focus:bg-slate-900 transition-all font-bold text-white placeholder:text-slate-700 tracking-wider"
              />
              <button 
                type="button" 
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-600 hover:text-cyan-400 transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {view === 'login' && (
              <div className="text-right">
                <button 
                  type="button" 
                  onClick={() => setView('forgot-password')}
                  className="text-[10px] font-black text-cyan-400 uppercase tracking-widest hover:text-white transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full py-5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black rounded-full shadow-2xl cyan-glow transition-all active:scale-95 flex items-center justify-center gap-3 text-sm uppercase tracking-widest disabled:opacity-50 mt-4"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-slate-950/20 border-t-slate-950 rounded-full animate-spin"></div>
              ) : (
                <>
                  {view === 'login' ? 'Authorize Login' : 'Create Identity'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-12 text-center">
            {view === 'forgot-password' ? (
              <button 
                onClick={() => setView('login')}
                className="text-[10px] font-black text-slate-600 uppercase tracking-widest hover:text-white flex items-center justify-center gap-2 mx-auto"
              >
                <ChevronLeft className="w-3 h-3" /> Back to Login
              </button>
            ) : (
              <p className="text-slate-600 text-[11px] font-bold tracking-widest uppercase">
                {view === 'login' ? "New to the platform?" : "Already a member?"}{' '}
                <button 
                  onClick={() => setView(view === 'login' ? 'signup' : 'login')}
                  className="text-cyan-400 hover:underline ml-1"
                >
                  {view === 'login' ? 'Register' : 'Login'}
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
