
import React from 'react';
import { ExternalLink, Sparkles, Star, ChevronRight, Bookmark } from 'lucide-react';
import { Course } from '../types';

interface SuggestedCoursesProps {
  suggestedCourses: Course[];
  isFetching?: boolean;
}

const SuggestedCourses: React.FC<SuggestedCoursesProps> = ({ suggestedCourses, isFetching }) => {
  return (
    <div className="bg-[#fcfcfd] py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-amber-100">
              <Sparkles className="w-3 h-3" />
              Hand-picked recommendations
            </div>
            <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter">
              Explore Our <span className="text-violet-600">Top Picks</span>
            </h2>
            <p className="text-lg text-slate-500 leading-relaxed font-medium">
              We've scanned hundreds of platforms to bring you these hand-picked courses. Click below to view the official course page.
            </p>
          </div>
          <button className="hidden md:flex items-center gap-2 text-violet-600 font-black text-sm hover:underline">
            Explore All Suggestions <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Course Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {isFetching ? (
            [1, 2].map(i => (
              <div key={i} className="bg-white rounded-[2.5rem] border border-gray-100 p-8 flex flex-col sm:flex-row gap-8">
                <div className="skeleton sm:w-2/5 h-48 rounded-2xl"></div>
                <div className="sm:w-3/5 space-y-4">
                  <div className="skeleton h-4 w-1/4 rounded"></div>
                  <div className="skeleton h-8 w-full rounded"></div>
                  <div className="skeleton h-16 w-full rounded"></div>
                  <div className="flex justify-between pt-4 border-t border-slate-50">
                    <div className="skeleton h-8 w-20 rounded"></div>
                    <div className="skeleton h-10 w-32 rounded-xl"></div>
                  </div>
                </div>
              </div>
            ))
          ) : suggestedCourses.map((course) => (
            <div 
              key={course.id} 
              className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl hover:border-violet-100 transition-all duration-500 overflow-hidden group flex flex-col sm:flex-row"
            >
              {/* Thumbnail Section */}
              <div className="sm:w-2/5 relative h-48 sm:h-auto">
                <img 
                  src={course.thumbnail} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  alt={course.title} 
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-[10px] font-black text-violet-600 rounded-lg uppercase tracking-widest border border-white">
                    {course.platform}
                  </span>
                </div>
              </div>

              {/* Info Section */}
              <div className="p-8 sm:w-3/5 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1.5 text-amber-500">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="text-sm font-bold text-slate-700">{course.rating}</span>
                  </div>
                  <button className="text-slate-300 hover:text-violet-600 transition-colors">
                    <Bookmark className="w-5 h-5" />
                  </button>
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-4 leading-snug group-hover:text-violet-600 transition-colors">
                  {course.title}
                </h3>

                <p className="text-sm text-slate-500 leading-relaxed mb-8 flex-1 italic">
                  "{course.description}"
                </p>

                <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                   <div>
                     <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1 tracking-wider">Estimated Price</span>
                     <span className="text-lg font-black text-slate-900">{course.price} TK</span>
                   </div>
                   <a 
                    href={course.affiliateUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-violet-600 text-white text-xs font-black rounded-2xl hover:bg-slate-900 transition-all shadow-lg shadow-violet-100 active:scale-95 uppercase tracking-widest"
                   >
                     Visit Course
                     <ExternalLink className="w-4 h-4" />
                   </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info Banner */}
        {!isFetching && (
          <div className="mt-20 p-10 bg-white border border-slate-100 rounded-[3rem] text-center relative overflow-hidden shadow-sm">
             <div className="relative z-10">
               <h3 className="text-2xl font-black text-slate-900 mb-4">Can't find your target course?</h3>
               <p className="text-slate-500 mb-8 max-w-xl mx-auto font-medium">
                 Let us know which course you'd like us to breakdown or suggest next. We'll audit it for you.
               </p>
               <button className="px-10 py-4 bg-slate-900 text-white text-xs font-black uppercase tracking-widest rounded-2xl hover:bg-violet-600 transition-all shadow-xl active:scale-95">
                  Request Audit
               </button>
             </div>
             <div className="absolute -top-10 -right-10 w-40 h-40 bg-violet-50 rounded-full blur-3xl opacity-50"></div>
             <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-amber-50 rounded-full blur-3xl opacity-50"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SuggestedCourses;
