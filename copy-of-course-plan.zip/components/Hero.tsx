
import React from 'react';
import { ArrowRight, Star, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface HeroProps {
  onExplore?: () => void;
  onHowItWorks?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onExplore, onHowItWorks }) => {
  return (
    <section className="relative pt-16 pb-32 lg:pt-28 lg:pb-56 overflow-hidden gradient-mesh">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10">
        <div className="flex flex-col items-center text-center">
          {/* Label Badge */}
          <div className="inline-flex items-center gap-3 px-6 py-2.5 rounded-full bg-white/5 backdrop-blur-md border border-white/10 text-cyan-400 text-[13px] font-bold mb-12 animate-in fade-in slide-in-from-bottom-2 duration-1000">
            <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse"></span>
            Intelligence for Smart Learning
            <Sparkles className="w-3.5 h-3.5 opacity-60" />
          </div>

          {/* Bengali Headline - Upgraded to tracking-wider */}
          <h1 className="text-5xl sm:text-7xl lg:text-[80px] font-extrabold text-white leading-[1.1] mb-12 tracking-wider animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-100 max-w-5xl font-['Outfit']">
            কোর্স কেনার আগে নিন <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-400">সঠিক গাইডলাইন</span>
          </h1>

          {/* Bengali Subheadline - Upgraded to tracking-wider */}
          <p className="text-xl sm:text-2xl text-slate-400 mb-16 leading-relaxed max-w-3xl font-medium tracking-wider animate-in fade-in slide-in-from-bottom-6 duration-1000 delay-200">
            মাত্র ৯৯-১৯৯ টাকায় পান ডিটেইল্ড কোর্স ব্রেকডাউন। প্রফেশনাল রিভিউ দেখে নিশ্চিত করুন আপনার কষ্টার্জিত টাকা সঠিক জায়গায় ইনভেস্ট হচ্ছে।
          </p>
          
          {/* Action Buttons - Linked to props */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 w-full sm:w-auto animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
            <button 
              onClick={onExplore}
              className="w-full sm:w-auto px-12 py-5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-lg font-bold rounded-full transition-all cyan-glow flex items-center justify-center gap-3 group active:scale-95"
            >
              View Course Breakdown
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform" />
            </button>
            <button 
              onClick={onHowItWorks}
              className="w-full sm:w-auto px-12 py-5 bg-white/5 hover:bg-white/10 text-white text-lg font-bold rounded-full border border-white/10 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              How It Works
            </button>
          </div>

          {/* Features */}
          <div className="mt-28 flex flex-wrap justify-center gap-x-16 gap-y-8 text-[11px] text-slate-500 font-bold uppercase tracking-[0.25em] animate-in fade-in duration-1500 delay-500">
            <div className="flex items-center gap-3">
              <Star className="w-4 h-4 text-cyan-400 fill-current" />
              Expert Audited
            </div>
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              Verified Insights
            </div>
            <div className="flex items-center gap-3">
              <Zap className="w-4 h-4 text-cyan-400" />
              Time Optimized
            </div>
          </div>
        </div>
      </div>

      <div className="absolute top-20 left-0 w-[50%] h-[50%] bg-cyan-500/10 blur-[140px] rounded-full -translate-x-1/2"></div>
      <div className="absolute bottom-10 right-0 w-[50%] h-[50%] bg-blue-500/10 blur-[140px] rounded-full translate-x-1/2"></div>
    </section>
  );
};

export default Hero;
