
import React from 'react';
import { createRoot } from 'react-dom/client';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info';

const Toast = ({ message, type, onClose }: { message: string, type: ToastType, onClose: () => void }) => {
  const bgColor = type === 'success' ? 'bg-emerald-500' : type === 'error' ? 'bg-rose-500' : 'bg-blue-500';
  const Icon = type === 'success' ? CheckCircle2 : type === 'error' ? AlertCircle : Info;

  return (
    <div className={`toast-card flex items-center gap-4 p-5 rounded-2xl shadow-2xl border border-white/10 text-white min-w-[320px] max-w-md ${bgColor} backdrop-blur-xl bg-opacity-90`}>
      <Icon className="w-6 h-6 flex-shrink-0" />
      <p className="flex-1 text-[13px] font-black uppercase tracking-wider">{message}</p>
      <button onClick={onClose} className="p-1 hover:bg-black/10 rounded-lg transition-colors">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};

export const showToast = (message: string, type: ToastType = 'info') => {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const div = document.createElement('div');
  container.appendChild(div);
  
  const root = createRoot(div);
  const remove = () => {
    root.unmount();
    div.remove();
  };

  root.render(<Toast message={message} type={type} onClose={remove} />);
  
  setTimeout(remove, 4000);
};
