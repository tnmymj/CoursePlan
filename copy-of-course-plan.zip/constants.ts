
import { Course, Affiliate } from './types';

const MOCK_BREAKDOWN = [
  { 
    title: '১. কোর্সের ওভারভিউ (Introduction)', 
    content: 'এই কোর্সটি মূলত বিগিনারদের জন্য ডিজাইন করা হয়েছে। এখানে আপনি পাবেন বেসিক থেকে এডভান্স লেভেলের গাইডলাইন। কোর্সের শুরুতে ইনস্ট্রাক্টর নিজের ক্যারিয়ার জার্নি শেয়ার করেছেন যা বেশ ইনস্পায়ারিং।', 
    isFree: true 
  },
  { 
    title: '২. মডিউল ডেপথ এনালাইসিস (Module Depth)', 
    content: 'কোর্সে মোট ১২টি মডিউল আছে। প্রথম ৫টি মডিউলে থিওরিটিক্যাল নলেজ দেওয়া হয়েছে। ভিডিও কোয়ালিটি বেশ ভালো এবং সাউন্ড ক্লিয়ার। তবে কিছু জায়গায় কোড এক্সপ্লেনেশন আরও ডিটেইল হতে পারতো।', 
    isFree: true 
  },
  { 
    title: '৩. প্র্যাকটিক্যাল প্রজেক্ট রিভিউ (Projects)', 
    content: 'এই কোর্সের সবচেয়ে শক্তিশালী দিক হলো এর প্রজেক্টগুলো। এখানে একটি রিয়েল-টাইম ই-কমার্স সাইট তৈরি করে দেখানো হয়েছে। রেডাক্স এবং নেক্সট জেএস এর ব্যবহার খুব চমৎকারভাবে শেখানো হয়েছে যা আপনাকে প্রফেশনাল লেভেলে কাজ করতে সাহায্য করবে।', 
    isFree: false 
  },
  { 
    title: '৪. সাপোর্ট এবং কমিউনিটি (Support)', 
    content: 'তাদের একটি প্রাইভেট ডিসকর্ড গ্রুপ আছে যেখানে মেন্টররা ২৪ ঘণ্টার মধ্যে উত্তর দেওয়ার চেষ্টা করেন। ক্যারিয়ার গাইডলাইন সেকশনটি এই কোর্সের বোনাস পয়েন্ট।', 
    isFree: false 
  },
  { 
    title: '৫. আমাদের রায় (Final Verdict)', 
    content: 'যদি আপনি বাজেট ফ্রেন্ডলি এবং প্রজেক্ট বেসড কিছু খুঁজছেন, তবে এটি সেরা। তবে এডভান্সড অ্যালগরিদম শিখতে চাইলে এটি আপনার জন্য নয়। রেটিং: ৪.৫/৫।', 
    isFree: false 
  }
];

export const COURSES: Course[] = [
  {
    id: '1',
    title: 'Complete Web Development Bootcamp 2024',
    platform: 'Udemy',
    description: 'A comprehensive guide to modern full-stack web development with React and Node.js.',
    price: 149,
    thumbnail: 'https://picsum.photos/seed/web/600/400',
    category: 'Development',
    rating: 4.8,
    breakdownSummary: ['Module-wise content depth', 'Project complexity analysis', 'Instructor responsiveness'],
    breakdownSections: MOCK_BREAKDOWN
  },
  {
    id: '2',
    title: 'UI/UX Design Masterclass',
    platform: 'Coursera',
    description: 'Learn the principles of user interface and experience design through hands-on labs.',
    price: 99,
    thumbnail: 'https://picsum.photos/seed/design/600/400',
    category: 'Design',
    rating: 4.6,
    breakdownSummary: ['Software tool coverage', 'Portfolio readiness', 'Theoretical foundations'],
    breakdownSections: MOCK_BREAKDOWN
  },
  {
    id: '3',
    title: 'Python for Data Science & Machine Learning',
    platform: 'Udemy',
    description: 'Go from zero to hero in Python data science with libraries like NumPy, Pandas, and Scikit-learn.',
    price: 199,
    thumbnail: 'https://picsum.photos/seed/python/600/400',
    category: 'Data Science',
    rating: 4.9,
    breakdownSummary: ['Mathematical rigor', 'Real-world dataset quality', 'Assignment difficulty'],
    breakdownSections: MOCK_BREAKDOWN
  }
];

// Added SUGGESTED_COURSES to resolve Error in components/SuggestedCourses.tsx on line 5
export const SUGGESTED_COURSES: Course[] = [
  {
    id: 's1',
    title: 'Advanced React Patterns',
    platform: 'Frontend Masters',
    description: 'Take your React skills to the next level with advanced patterns and performance optimization.',
    price: 250,
    thumbnail: 'https://picsum.photos/seed/react-adv/600/400',
    category: 'Development',
    rating: 4.9,
    breakdownSummary: ['Context API optimization', 'Render props vs Hooks', 'Performance profiling'],
    affiliateUrl: 'https://example.com/react-adv'
  },
  {
    id: 's2',
    title: 'Fullstack Next.js Guide',
    platform: 'Vercel',
    description: 'Learn to build production-ready applications with Next.js 14 and the App Router.',
    price: 180,
    thumbnail: 'https://picsum.photos/seed/nextjs/600/400',
    category: 'Development',
    rating: 4.7,
    breakdownSummary: ['Server Components', 'Streaming and Suspense', 'Database integration'],
    affiliateUrl: 'https://example.com/nextjs'
  }
];

export const AFFILIATES: Affiliate[] = [
  {
    id: 'aff-1',
    name: '10 Minute School',
    logo: 'https://picsum.photos/seed/10ms/100',
    description: 'Bangladesh\'s largest online learning platform for academic and skill development.',
    categories: ['Academic', 'Skills', 'Job Prep'],
    url: 'https://10minuteschool.com',
    type: 'PLATFORM'
  },
  {
    id: 'aff-2',
    name: 'Ostad',
    logo: 'https://picsum.photos/seed/ostad/100',
    description: 'Live cohort-based learning platform for modern tech skills and career guidance.',
    categories: ['Development', 'Design', 'Marketing'],
    url: 'https://ostad.app',
    type: 'PLATFORM'
  },
  {
    id: 'aff-c1',
    name: 'Complete Freelancing Course',
    logo: 'https://picsum.photos/seed/freelance/100',
    description: 'Master the art of freelancing on platforms like Upwork and Fiverr.',
    categories: ['Freelancing', 'Career'],
    url: 'https://example.com/freelance-affiliate',
    type: 'COURSE'
  },
  {
    id: 'aff-c2',
    name: 'Advanced Graphics Design',
    logo: 'https://picsum.photos/seed/graphics/100',
    description: 'High-quality graphics design course for aspiring professionals.',
    categories: ['Design', 'Creative'],
    url: 'https://example.com/graphics-affiliate',
    type: 'COURSE'
  }
];
