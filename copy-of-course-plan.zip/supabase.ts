
import { createClient } from '@supabase/supabase-js';

// Safely access environment variables with optional chaining to prevent "Cannot read properties of undefined"
// We also provide hardcoded fallbacks to ensure the app works even if environment variables are not yet configured.
const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://bxkliwwypaijcjxvqoti.supabase.co';
const supabaseKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_AUcc0ZwvflXLu8OynxWQqg_JnmURceP';

if (!supabaseUrl || supabaseUrl.includes('your-project')) {
  console.warn("Supabase configuration is using default or placeholder values.");
}

export const supabase = createClient(supabaseUrl, supabaseKey);
