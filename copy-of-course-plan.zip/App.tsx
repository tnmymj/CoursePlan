
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CourseGrid from './components/CourseGrid';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import Dashboard from './components/Dashboard';
import ManagementDashboard from './components/ManagementDashboard';
import SuggestedCourses from './components/SuggestedCourses';
import BreakdownViewer from './components/BreakdownViewer';
import Marketplace from './components/Marketplace';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import { supabase } from './supabase';
import { NavItem, UserRole, UserProfile, Course, Affiliate } from './types';
// Added CreditCard to the imports to resolve "Cannot find name 'CreditCard'" error
import { Zap, ShoppingBag, Sparkles, CreditCard } from 'lucide-react';
import { showToast } from './components/Toast';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isDataFetching, setIsDataFetching] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNav, setActiveNav] = useState<NavItem | 'Dashboard' | 'Management'>('Home');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [globalCourses, setGlobalCourses] = useState<Course[]>([]);
  const [globalAffiliates, setGlobalAffiliates] = useState<Affiliate[]>([]);
  const [globalSuggestedCourses, setGlobalSuggestedCourses] = useState<Course[]>([]);

  useEffect(() => {
    const initApp = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        await fetchUserProfile(session.user.id, session.user.email!);
      }
      setIsLoading(false);
      try {
        await Promise.all([fetchCourses(), fetchAffiliates(), fetchSuggestions()]);
      } finally {
        setIsDataFetching(false);
      }
    };

    initApp();

    // Check for payment success status in URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('payment') === 'success') {
      showToast('Payment successful! Your course is being unlocked.', 'success');
      // Remove params without refreshing
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session) {
        await fetchUserProfile(session.user.id, session.user.email!);
      } else {
        setUser(null);
        setActiveNav('Home');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserProfile = async (userId: string, email: string) => {
    try {
      let assignedRole: UserRole = 'USER';
      if (email === 'tonmoymbm@gmail.com') assignedRole = 'SUPER_ADMIN';
      else if (email === 'tnmymj@gmail.com') assignedRole = 'ADMIN';

      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();

      if (error && error.code === 'PGRST116') {
        const newProfile = {
          id: userId,
          email: email,
          name: email.split('@')[0].toUpperCase(),
          role: assignedRole,
          avatar: `https://ui-avatars.com/api/?name=${email.split('@')[0]}&background=22d3ee&color=020617`,
          bio: '',
          purchased_course_ids: []
        };
        await supabase.from('profiles').insert([newProfile]);
        setUser({ ...newProfile, purchasedCourseIds: [] } as UserProfile);
      } else if (data) {
        setUser({ ...data, purchasedCourseIds: data.purchased_course_ids || [] } as UserProfile);
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
    }
  };

  const fetchCourses = async () => {
    try {
      const { data } = await supabase.from('courses').select('*').order('created_at', { ascending: false });
      if (data) setGlobalCourses(data.map(c => ({ ...c, breakdownSections: c.breakdown_sections || [] })));
    } catch (err) { console.error(err); }
  };

  const fetchAffiliates = async () => {
    try {
      const { data } = await supabase.from('affiliates').select('*');
      if (data) setGlobalAffiliates(data);
    } catch (err) { console.error(err); }
  };

  const fetchSuggestions = async () => {
    try {
      const { data } = await supabase.from('suggested_courses').select('*');
      if (data) setGlobalSuggestedCourses(data.map(s => ({ ...s, affiliateUrl: s.affiliate_url })));
    } catch (err) { console.error(err); }
  };

  // Real Payment Logic with UddoktaPay via Supabase Edge Functions
  const handlePurchase = async (courseId: string) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    if (user.purchasedCourseIds?.includes(courseId)) {
      showToast('You already own this audit.', 'info');
      return;
    }

    try {
      showToast('Redirecting to payment gateway...', 'info');
      
      // Step 1: Call Supabase Edge Function to create UddoktaPay checkout
      // You need to create an edge function named 'create-checkout' in Supabase
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: { 
          courseId, 
          userId: user.id,
          customerName: user.name,
          customerEmail: user.email,
          amount: globalCourses.find(c => c.id === courseId)?.price || 99
        }
      });

      if (error) throw error;

      // Step 2: Redirect to UddoktaPay hosted payment page
      if (data?.payment_url) {
        window.location.href = data.payment_url;
      } else {
        throw new Error('Failed to generate payment link');
      }

    } catch (err: any) {
      console.error('Payment Error:', err);
      showToast('Payment failed: ' + err.message, 'error');
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    showToast('Signed out successfully', 'info');
  };

  const handleViewBreakdown = (course: Course) => {
    setSelectedCourse(course);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  const isManagementRole = user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN' || user.role === 'ANALYST');

  return (
    <div className="min-h-screen flex flex-col selection:bg-cyan-500/30 selection:text-white bg-[#020617]">
      {activeNav !== 'Management' && (
        <Header 
          onSearch={setSearchQuery} 
          activeNav={activeNav} 
          setActiveNav={(nav) => {
            if (['Suggested Courses', 'Course Breakdown', 'How It Works'].includes(nav)) {
              const ids: Record<string, string> = { 'Suggested Courses': 'suggested-section', 'Course Breakdown': 'breakdowns', 'How It Works': 'features-section' };
              setActiveNav('Home');
              setTimeout(() => scrollToSection(ids[nav]), 100);
            } else {
              setActiveNav(nav);
              setSelectedCourse(null);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          isLoggedIn={!!user}
          userRole={user?.role}
          userName={user?.name}
          onOpenAuth={() => setIsAuthModalOpen(true)}
        />
      )}
      
      <main className="flex-grow">
        {isLoading ? (
          <div className="fixed inset-0 bg-[#020617] flex flex-col items-center justify-center z-[200]">
             <div className="w-16 h-16 border-4 border-cyan-500/20 border-t-cyan-500 rounded-full animate-spin mb-8 shadow-[0_0_20px_rgba(34,211,238,0.3)]"></div>
             <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em] animate-pulse">Initializing Interface...</p>
          </div>
        ) : selectedCourse ? (
          <BreakdownViewer 
            course={selectedCourse} 
            user={user}
            onBack={() => setSelectedCourse(null)}
            onPurchase={handlePurchase}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        ) : activeNav === 'Management' && user && isManagementRole ? (
          <ManagementDashboard 
            user={user}
            userRole={user.role} 
            courses={globalCourses}
            setCourses={setGlobalCourses}
            affiliates={globalAffiliates}
            setAffiliates={setGlobalAffiliates}
            suggestedCourses={globalSuggestedCourses}
            setSuggestedCourses={setGlobalSuggestedCourses}
            onLogout={handleLogout} 
            onBackToMain={() => setActiveNav('Home')}
          />
        ) : activeNav === 'Dashboard' && user ? (
          <Dashboard 
            user={user} 
            onLogout={handleLogout} 
            onViewCourse={handleViewBreakdown}
            allCourses={globalCourses}
            suggestedCourses={globalSuggestedCourses}
            affiliates={globalAffiliates}
            onNavigateToManagement={isManagementRole ? () => setActiveNav('Management') : undefined}
            onUpdateProfile={(updatedUser) => setUser(updatedUser)}
          />
        ) : activeNav === 'Marketplace' ? (
          <Marketplace affiliates={globalAffiliates} isFetching={isDataFetching} />
        ) : activeNav === 'Privacy Policy' ? (
          <PrivacyPolicy onBack={() => setActiveNav('Home')} />
        ) : activeNav === 'Terms of Service' ? (
          <TermsOfService onBack={() => setActiveNav('Home')} />
        ) : (
          <>
            {activeNav === 'Home' && (
              <Hero 
                onExplore={() => scrollToSection('breakdowns')}
                onHowItWorks={() => scrollToSection('features-section')}
              />
            )}
            
            {activeNav === 'Home' && (
              <section id="features-section" className="py-32 bg-slate-950 relative overflow-hidden">
                <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10 text-center">
                  <h2 className="text-4xl sm:text-5xl font-extrabold text-white mb-10 font-['Outfit'] tracking-wider">এটি কীভাবে কাজ করে</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-20">
                    <div className="bg-slate-900 p-12 rounded-[3rem] border border-white/5 flex flex-col items-center group hover:bg-slate-800 transition-all">
                      <Zap className="w-12 h-12 text-cyan-400 mb-6" />
                      <h3 className="text-2xl font-bold mb-4 text-white">১. কোর্স বাছাই</h3>
                      <p className="text-slate-400">আপনার পছন্দের কোর্সটি সিলেক্ট করুন।</p>
                    </div>
                    <div className="bg-slate-900 p-12 rounded-[3rem] border border-white/5 flex flex-col items-center group hover:bg-slate-800 transition-all">
                      <CreditCard className="w-12 h-12 text-cyan-400 mb-6" />
                      <h3 className="text-2xl font-bold mb-4 text-white">২. পেমেন্ট করুন</h3>
                      <p className="text-slate-400">নিরাপদ পেমেন্ট গেটওয়ের মাধ্যমে পেমেন্ট সম্পন্ন করুন।</p>
                    </div>
                    <div className="bg-slate-900 p-12 rounded-[3rem] border border-white/5 flex flex-col items-center group hover:bg-slate-800 transition-all">
                      <Sparkles className="w-12 h-12 text-cyan-400 mb-6" />
                      <h3 className="text-2xl font-bold mb-4 text-white">৩. অডিট এক্সেস</h3>
                      <p className="text-slate-400">পুরো ব্রেকডাউনটি সারা জীবনের জন্য আনলক করুন।</p>
                    </div>
                  </div>
                </div>
              </section>
            )}

            <div id="breakdowns">
              <CourseGrid courses={globalCourses} isFetching={isDataFetching} searchQuery={searchQuery} onViewBreakdown={handleViewBreakdown} />
            </div>

            <div id="suggested-section">
              <SuggestedCourses suggestedCourses={globalSuggestedCourses} isFetching={isDataFetching} />
            </div>
          </>
        )}
      </main>

      {activeNav !== 'Management' && <Footer setActiveNav={(nav) => { setActiveNav(nav); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </div>
  );
};

export default App;
